<?php
header('Location: /BMirk/staff/posts/events_history.php', true, 302);
exit;
