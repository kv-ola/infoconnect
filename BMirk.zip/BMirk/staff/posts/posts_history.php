<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/session.php';
requireLogin();

if (($_SESSION['role'] ?? '') !== 'staff') {
	header('Location: /BMirk/auth/login.php');
	exit;
}

$page_title = 'History';
$staffId = (int) ($_SESSION['user_id'] ?? 0);
$historyItems = [];
$historyStatement = $databaseConnection->prepare(
	"SELECT 'event' AS post_type, e.title,
	        CONCAT_WS(' · ', DATE_FORMAT(e.event_date, '%b %e, %Y'),
	            CONCAT(TIME_FORMAT(e.start_time, '%h:%i %p'),
	                CASE WHEN e.end_time IS NOT NULL THEN CONCAT(' - ', TIME_FORMAT(e.end_time, '%h:%i %p')) ELSE '' END)) AS schedule,
	        CONCAT_WS(' | ', e.location, NULLIF(LEFT(e.description, 240), '')) AS details,
	        e.status AS post_status, COALESCE(ar.reviewed_at, e.updated_at) AS approved_at
	 FROM events e
	 INNER JOIN approval_requests ar
	   ON ar.request_type = 'event' AND ar.reference_id = e.id
	  AND ar.id = (
	      SELECT latest_ar.id FROM approval_requests latest_ar
	      WHERE latest_ar.request_type = 'event' AND latest_ar.reference_id = e.id
	        AND latest_ar.requested_by = e.created_by
	      ORDER BY latest_ar.created_at DESC, latest_ar.id DESC LIMIT 1
	  )
	 WHERE e.created_by = ? AND ar.status = 'approved'
	   AND e.status IN ('approved', 'published', 'completed')
	 UNION ALL
	 SELECT 'announcement' AS post_type, a.title,
	        CASE WHEN a.expires_at IS NOT NULL THEN CONCAT('Expires ', DATE_FORMAT(a.expires_at, '%b %e, %Y')) ELSE 'No expiry' END AS schedule,
	        LEFT(a.content, 240) AS details, a.status AS post_status,
	        COALESCE(ar.reviewed_at, a.updated_at) AS approved_at
	 FROM announcements a
	 INNER JOIN approval_requests ar
	   ON ar.request_type = 'announcement' AND ar.reference_id = a.id
	  AND ar.id = (
	      SELECT latest_ar.id FROM approval_requests latest_ar
	      WHERE latest_ar.request_type = 'announcement' AND latest_ar.reference_id = a.id
	        AND latest_ar.requested_by = a.created_by
	      ORDER BY latest_ar.created_at DESC, latest_ar.id DESC LIMIT 1
	  )
	 WHERE a.created_by = ? AND ar.status = 'approved'
	   AND a.status IN ('approved', 'published')
	 ORDER BY approved_at DESC"
);
if (!$historyStatement) {
	error_log('Unable to prepare Staff post history query: ' . $databaseConnection->error);
	throw new RuntimeException('Unable to load approved post history.');
}
$historyStatement->bind_param('ii', $staffId, $staffId);
if (!$historyStatement->execute()) {
	error_log('Unable to execute Staff post history query: ' . $historyStatement->error);
	throw new RuntimeException('Unable to load approved post history.');
}
$historyResult = $historyStatement->get_result();
while ($row = $historyResult->fetch_assoc()) {
	$historyItems[] = $row;
}
$historyStatement->close();

function escapeStaffPostHistory($value): string
{
	return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo escapeStaffPostHistory($page_title); ?></title>
	<link rel="stylesheet" href="../home.css">
	<link rel="stylesheet" href="../assets/table.css?v=18">
	<link rel="stylesheet" href="assets/posts.css?v=5">
</head>
<body>
	<div class="staff-layout">
		<?php include __DIR__ . '/../includes/sidebar.php'; ?>
		<main class="staff-main">
			<?php include __DIR__ . '/../includes/header.php'; ?>
			<section class="staff-content staff-posts-page">
				<header class="staff-posts-heading">
					<div>
						<h1>History</h1>
						<p>Approved events and announcements you submitted.</p>
					</div>
				</header>
				<section class="staff-posts-panel" aria-label="Approved post history">
					<div class="staff-post-list-filters">
						<div class="staff-post-search staff-search-field">
							<label class="staff-search-label" for="historySearch">Search</label>
							<div class="staff-post-search-group">
								<input id="historySearch" type="search" placeholder="Search title or details..." aria-label="Search post history">
							</div>
						</div>
						<label class="staff-post-filter">
							<span>Post Type</span>
							<select id="historyType">
								<option value="all">All</option>
								<option value="event">Event</option>
								<option value="announcement">Announcement</option>
							</select>
						</label>
					</div>
					<div class="staff-post-table-wrap staff-consistent-table-wrap">
						<table class="data-table staff-consistent-table staff-post-table" id="postHistoryTable">
							<thead><tr><th>#</th><th>Title</th><th>Type</th><th>Schedule</th><th>Details</th><th>Status</th><th>Approved on</th></tr></thead>
							<tbody>
							<?php foreach ($historyItems as $index => $item): ?>
								<?php $status = strtolower((string) $item['post_status']); ?>
								<tr data-type="<?php echo escapeStaffPostHistory($item['post_type']); ?>" data-search="<?php echo escapeStaffPostHistory(mb_strtolower($item['title'] . ' ' . $item['details'], 'UTF-8')); ?>">
									<td class="staff-post-row-number"><?php echo $index + 1; ?></td>
									<td class="staff-post-title"><strong><?php echo escapeStaffPostHistory($item['title']); ?></strong></td>
									<td><span class="staff-post-type-badge <?php echo escapeStaffPostHistory($item['post_type']); ?>"><?php echo escapeStaffPostHistory(ucfirst($item['post_type'])); ?></span></td>
									<td><?php echo escapeStaffPostHistory($item['schedule']); ?></td>
									<td class="archive-details"><?php echo escapeStaffPostHistory($item['details']); ?></td>
									<td><span class="staff-post-status <?php echo escapeStaffPostHistory($status); ?>"><?php echo escapeStaffPostHistory(ucfirst($status)); ?></span></td>
									<td><?php echo escapeStaffPostHistory(date('M j, Y g:i A', strtotime((string) $item['approved_at']))); ?></td>
								</tr>
							<?php endforeach; ?>
							<tr id="historyEmpty" hidden><td colspan="7">No approved posts found.</td></tr>
							</tbody>
						</table>
					</div>
					<footer class="staff-post-table-footer staff-consistent-table-footer">
						<p class="staff-consistent-result-count" id="historyCount" aria-live="polite"></p>
						<div class="staff-consistent-pagination" id="historyPagination" aria-label="History result pages"></div>
					</footer>
				</section>
			</section>
		</main>
	</div>
	<script>
		const historyRows = Array.from(document.querySelectorAll('#postHistoryTable tbody tr[data-type]'));
		const historySearch = document.getElementById('historySearch');
		const historyType = document.getElementById('historyType');
		const historyEmpty = document.getElementById('historyEmpty');
		const historyCount = document.getElementById('historyCount');
		const historyPagination = document.getElementById('historyPagination');
		const historyPageSize = 10;
		let historyPage = 1;
		function renderHistory() {
			const term = historySearch.value.trim().toLocaleLowerCase();
			const type = historyType.value;
			const filtered = historyRows.filter(function (row) {
				return (type === 'all' || row.dataset.type === type) && (!term || row.dataset.search.includes(term));
			});
			const pages = Math.max(1, Math.ceil(filtered.length / historyPageSize));
			historyPage = Math.min(historyPage, pages);
			const start = (historyPage - 1) * historyPageSize;
			const visible = filtered.slice(start, start + historyPageSize);
			historyRows.forEach(function (row) { row.hidden = !visible.includes(row); });
			historyEmpty.hidden = filtered.length > 0;
			historyCount.textContent = filtered.length ? 'Showing ' + (start + 1) + ' to ' + (start + visible.length) + ' of ' + filtered.length + ' posts' : 'Showing 0 posts';
			if (pages <= 1) {
				historyPagination.innerHTML = '<span>Page 1 of 1</span>';
				return;
			}
			const buttons = [];
			for (let page = 1; page <= pages; page++) buttons.push('<button type="button" data-page="' + page + '"' + (page === historyPage ? ' aria-current="page"' : '') + '>' + page + '</button>');
			historyPagination.innerHTML = buttons.join('');
			historyPagination.querySelectorAll('button[data-page]').forEach(function (button) {
				button.addEventListener('click', function () { historyPage = Number(button.dataset.page); renderHistory(); });
			});
		}
		[historySearch, historyType].forEach(function (control) {
			control.addEventListener('input', function () { historyPage = 1; renderHistory(); });
			control.addEventListener('change', function () { historyPage = 1; renderHistory(); });
		});
		renderHistory();
	</script>
</body>
</html>
