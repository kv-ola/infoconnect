<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/session.php';
requireLogin();

if (($_SESSION['role'] ?? '') !== 'staff') {
	header('Location: /BMirk/auth/login.php');
	exit;
}

$page_title = 'Announcements';
$staffId = (int) ($_SESSION['user_id'] ?? 0);
$announcements = [];
$announcementStatement = $databaseConnection->prepare(
	"SELECT a.id, a.title, a.content, a.expires_at, a.created_at, a.status,
	        ar.status AS approval_status, COALESCE(ar.reviewed_at, a.updated_at) AS action_at
	 FROM announcements a
	 INNER JOIN approval_requests ar
	   ON ar.request_type = 'announcement'
	  AND ar.reference_id = a.id
	  AND ar.id = (
	      SELECT latest_ar.id
	      FROM approval_requests latest_ar
	      WHERE latest_ar.request_type = 'announcement'
	        AND latest_ar.reference_id = a.id
	        AND latest_ar.requested_by = a.created_by
	      ORDER BY latest_ar.created_at DESC, latest_ar.id DESC
	      LIMIT 1
	  )
	 WHERE ar.status = 'pending' AND a.status = 'pending' AND a.created_by = ?
	 ORDER BY COALESCE(ar.reviewed_at, a.updated_at) DESC, a.id DESC"
);
if (!$announcementStatement) {
	error_log('Unable to prepare Staff announcements query: ' . $databaseConnection->error);
	throw new RuntimeException('Unable to load announcements.');
}
	$announcementStatement->bind_param('i', $staffId);
if (!$announcementStatement->execute()) {
	error_log('Unable to execute Staff announcements query: ' . $announcementStatement->error);
	throw new RuntimeException('Unable to load announcements.');
}
$announcementResult = $announcementStatement->get_result();
while ($row = $announcementResult->fetch_assoc()) {
	$announcements[] = $row;
}
$announcementStatement->close();

function escapeStaffAnnouncement($value): string
{
	return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo escapeStaffAnnouncement($page_title); ?></title>
	<link rel="stylesheet" href="../home.css">
	<link rel="stylesheet" href="../assets/table.css?v=18">
	<link rel="stylesheet" href="assets/posts.css?v=3">
</head>
<body>
	<div class="staff-layout">
		<?php include __DIR__ . '/../includes/sidebar.php'; ?>
		<main class="staff-main">
			<?php include __DIR__ . '/../includes/header.php'; ?>
			<section class="staff-content staff-posts-page">
				<header class="staff-posts-heading">
					<div>
						<h1>Announcements</h1>
						<p>View your announcements awaiting review.</p>
					</div>
				</header>

				<section class="staff-posts-panel" aria-label="Announcements">
					<form class="staff-post-list-filters" id="announcementFilters">
						<div class="staff-post-search staff-search-field">
							<label class="staff-search-label" for="announcementSearch">Search</label>
							<div class="staff-post-search-group">
								<input id="announcementSearch" type="search" placeholder="Search title or content..." aria-label="Search announcements">
								<button type="submit" class="staff-post-search-button">Search</button>
							</div>
						</div>
					</form>

					<div class="staff-post-table-wrap staff-consistent-table-wrap">
						<table class="data-table staff-consistent-table staff-post-table" id="announcementTable">
							<thead>
								<tr>
									<th>#</th>
									<th>Title</th>
									<th>Content</th>
									<th>Expiry</th>
									<th>Status</th>
									<th>Submitted</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($announcements as $index => $announcement): ?>
									<?php
									$expiresAt = $announcement['expires_at']
										? date('M j, Y', strtotime((string) $announcement['expires_at']))
										: 'No expiry';
									$actionAt = date('M j, Y g:i A', strtotime((string) $announcement['action_at']));
									$displayStatus = $announcement['approval_status'] === 'pending' ? 'pending' : strtolower((string) $announcement['status']);
									?>
									<tr data-title="<?php echo escapeStaffAnnouncement(mb_strtolower((string) $announcement['title'], 'UTF-8')); ?>"
										data-content="<?php echo escapeStaffAnnouncement(mb_strtolower((string) $announcement['content'], 'UTF-8')); ?>">
										<td class="staff-post-row-number"><?php echo $index + 1; ?></td>
										<td class="staff-post-title"><strong><?php echo escapeStaffAnnouncement($announcement['title']); ?></strong></td>
										<td class="announcement-content"><span><?php echo escapeStaffAnnouncement($announcement['content']); ?></span></td>
										<td><?php echo escapeStaffAnnouncement($expiresAt); ?></td>
									<td><span class="staff-post-status <?php echo escapeStaffAnnouncement($displayStatus); ?>"><?php echo escapeStaffAnnouncement(ucfirst($displayStatus)); ?></span></td>
									<td><?php echo escapeStaffAnnouncement($actionAt); ?></td>
									</tr>
								<?php endforeach; ?>
								<tr id="announcementEmpty" hidden>
									<td colspan="6">No announcements match this view.</td>
								</tr>
							</tbody>
						</table>
					</div>

					<footer class="staff-post-table-footer staff-consistent-table-footer">
						<p class="staff-consistent-result-count" id="announcementResultCount" aria-live="polite"></p>
						<div class="staff-post-pagination staff-consistent-pagination" id="announcementPagination" aria-label="Announcement result pages"></div>
					</footer>
				</section>
			</section>
		</main>
	</div>
	<script>
		const announcementRows = Array.from(document.querySelectorAll('#announcementTable tbody tr[data-title]'));
		const announcementSearch = document.getElementById('announcementSearch');
		const announcementEmpty = document.getElementById('announcementEmpty');
		const announcementResultCount = document.getElementById('announcementResultCount');
		const announcementPagination = document.getElementById('announcementPagination');
		const announcementPageSize = 10;
		let currentAnnouncementPage = 1;

		function applyAnnouncementFilters() {
			const term = announcementSearch.value.trim().toLocaleLowerCase();
			const filteredRows = announcementRows.filter(function (row) {
				return !term || row.dataset.title.includes(term) || row.dataset.content.includes(term);
			});
			const totalPages = Math.max(1, Math.ceil(filteredRows.length / announcementPageSize));
			currentAnnouncementPage = Math.min(currentAnnouncementPage, totalPages);
			const start = (currentAnnouncementPage - 1) * announcementPageSize;
			const visibleRows = filteredRows.slice(start, start + announcementPageSize);
			announcementRows.forEach(function (row) {
				row.hidden = !visibleRows.includes(row);
				if (!row.hidden) {
					row.querySelector('.staff-post-row-number').textContent = String(filteredRows.indexOf(row) + 1);
				}
			});
			announcementEmpty.hidden = filteredRows.length !== 0;
			announcementResultCount.textContent = filteredRows.length
				? 'Showing ' + (start + 1) + ' to ' + (start + visibleRows.length) + ' of ' + filteredRows.length + ' announcements'
				: 'Showing 0 announcements';
			renderAnnouncementPagination(totalPages);
		}

		function renderAnnouncementPagination(totalPages) {
			if (totalPages <= 1) {
				announcementPagination.innerHTML = '<span>Page 1 of 1</span>';
				return;
			}
			const buttons = [];
			for (let page = 1; page <= totalPages; page++) {
				buttons.push('<button type="button" data-page="' + page + '"' + (page === currentAnnouncementPage ? ' aria-current="page"' : '') + '>' + page + '</button>');
			}
			announcementPagination.innerHTML =
				'<button type="button" data-page="' + (currentAnnouncementPage - 1) + '" aria-label="Previous page"' + (currentAnnouncementPage === 1 ? ' disabled' : '') + '>Previous</button>' +
				buttons.join('') +
				'<button type="button" data-page="' + (currentAnnouncementPage + 1) + '" aria-label="Next page"' + (currentAnnouncementPage === totalPages ? ' disabled' : '') + '>Next</button>';
			announcementPagination.querySelectorAll('button[data-page]').forEach(function (button) {
				button.addEventListener('click', function () {
					const targetPage = Number(button.dataset.page);
					if (targetPage >= 1 && targetPage <= totalPages) {
						currentAnnouncementPage = targetPage;
						applyAnnouncementFilters();
					}
				});
			});
		}

		document.getElementById('announcementFilters').addEventListener('submit', function (event) {
			event.preventDefault();
			currentAnnouncementPage = 1;
			applyAnnouncementFilters();
		});
		announcementSearch.addEventListener('input', function () {
			currentAnnouncementPage = 1;
			applyAnnouncementFilters();
		});
		applyAnnouncementFilters();
	</script>
</body>
</html>
