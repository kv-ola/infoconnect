<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/session.php';
requireLogin();

if (($_SESSION['role'] ?? '') !== 'staff') {
	header('Location: /BMirk/auth/login.php');
	exit;
}

$page_title = 'Archive';
$staffId = (int) ($_SESSION['user_id'] ?? 0);
$staffFirstName = $_SESSION['account_id'] ?? 'Staff';
$staffProfileStatement = $databaseConnection->prepare('SELECT first_name FROM staff_profiles WHERE user_id = ? LIMIT 1');
if ($staffProfileStatement) {
	$staffProfileStatement->bind_param('i', $staffId);
	$staffProfileStatement->execute();
	$staffProfile = $staffProfileStatement->get_result()->fetch_assoc();
	if (!empty($staffProfile['first_name'])) {
		$staffFirstName = $staffProfile['first_name'];
	}
}

$historyItems = [];
$historyStatement = $databaseConnection->prepare(
	"SELECT ar.request_type, ar.status AS approval_status, ar.remarks, ar.created_at AS submitted_at,
	        e.title,
	        DATE_FORMAT(e.event_date, '%b %e, %Y') AS schedule,
	        CONCAT_WS(' | ',
	            CONCAT(TIME_FORMAT(e.start_time, '%h:%i %p'),
	                CASE WHEN e.end_time IS NOT NULL THEN CONCAT(' - ', TIME_FORMAT(e.end_time, '%h:%i %p')) ELSE '' END),
	            e.location,
	            NULLIF(LEFT(e.description, 240), '')
	        ) AS details
	 FROM approval_requests ar
	 INNER JOIN events e ON ar.request_type = 'event' AND e.id = ar.reference_id
	 WHERE ar.requested_by = ? AND ar.request_type = 'event' AND ar.status = 'rejected'
	   AND ar.id = (
	       SELECT latest_ar.id FROM approval_requests latest_ar
	       WHERE latest_ar.request_type = 'event' AND latest_ar.reference_id = e.id
	         AND latest_ar.requested_by = ar.requested_by
	       ORDER BY latest_ar.created_at DESC, latest_ar.id DESC LIMIT 1
	   )
	 UNION ALL
	 SELECT ar.request_type, ar.status AS approval_status, ar.remarks, ar.created_at AS submitted_at,
	        a.title,
	        CASE WHEN a.expires_at IS NOT NULL THEN DATE_FORMAT(a.expires_at, '%b %e, %Y') ELSE 'No expiry' END AS schedule,
	        LEFT(a.content, 240) AS details
	 FROM approval_requests ar
	 INNER JOIN announcements a ON ar.request_type = 'announcement' AND a.id = ar.reference_id
	 WHERE ar.requested_by = ? AND ar.request_type = 'announcement' AND ar.status = 'rejected'
	   AND ar.id = (
	       SELECT latest_ar.id FROM approval_requests latest_ar
	       WHERE latest_ar.request_type = 'announcement' AND latest_ar.reference_id = a.id
	         AND latest_ar.requested_by = ar.requested_by
	       ORDER BY latest_ar.created_at DESC, latest_ar.id DESC LIMIT 1
	   )
	 ORDER BY submitted_at DESC"
);
if (!$historyStatement) {
	error_log('Unable to prepare Staff posts archive query: ' . $databaseConnection->error);
	throw new RuntimeException('Unable to load your post history.');
}
$historyStatement->bind_param('ii', $staffId, $staffId);
if (!$historyStatement->execute()) {
	error_log('Unable to execute Staff posts archive query: ' . $historyStatement->error);
	throw new RuntimeException('Unable to load your post history.');
}
$historyResult = $historyStatement->get_result();
while ($row = $historyResult->fetch_assoc()) {
	$historyItems[] = [
		'title' => $row['title'],
		'type' => ucfirst($row['request_type']),
		'submitted_at' => $row['submitted_at'],
		'schedule' => $row['schedule'],
		'details' => $row['details'],
		'approval_status' => ucfirst($row['approval_status']),
		'remarks' => $row['remarks'] ?? ''
	];
}
$historyStatement->close();

function escapeArchiveValue($value): string
{
	return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo escapeArchiveValue($page_title); ?></title>
	<link rel="stylesheet" href="../home.css">

	<link rel="stylesheet" href="../assets/table.css?v=18">
	<link rel="stylesheet" href="assets/posts.css?v=5">
</head>
<body>
	<div class="staff-layout">
		<?php include __DIR__ . '/../includes/sidebar.php'; ?>

		<main class="staff-main">
			<?php include __DIR__ . '/../includes/header.php'; ?>

			<section class="staff-content staff-archive-page">
				<header class="staff-archive-heading">
					<div>
						<h1>Archive</h1>
						<p>Rejected events and announcements submitted by you.</p>
					</div>
				</header>

				<div class="page-card staff-archive-card">
					<div class="archive-filter-toolbar">
						<label class="filter-field">
							<span>Post type</span>
							<select id="typeFilter">
								<option value="All">All</option>
								<option value="Event">Event</option>
								<option value="Announcement">Announcement</option>
							</select>
						</label>
					</div>

					<div class="table-wrap staff-consistent-table-wrap archive-table-wrap">
						<table class="data-table staff-consistent-table archive-table">
							<thead>
								<tr>
									<th>#</th>
									<th>Title</th>
									<th>Type</th>
									<th>Submitted on</th>
									<th>Schedule / expiry</th>
									<th>Details</th>
									<th>Status</th>
									<th>Remarks</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($historyItems as $index => $item): ?>
									<tr data-type="<?php echo escapeArchiveValue($item['type']); ?>" data-status="<?php echo escapeArchiveValue($item['approval_status']); ?>">
										<td class="archive-row-number"><?php echo $index + 1; ?></td>
										<td class="archive-title"><?php echo escapeArchiveValue($item['title']); ?></td>
										<td><?php echo escapeArchiveValue($item['type']); ?></td>
										<td><?php echo escapeArchiveValue(date('M j, Y g:i A', strtotime($item['submitted_at']))); ?></td>
										<td><?php echo escapeArchiveValue($item['schedule']); ?></td>
										<td class="archive-details"><?php echo escapeArchiveValue($item['details']); ?></td>
										<td><span class="status-badge <?php echo escapeArchiveValue(strtolower($item['approval_status'])); ?>"><?php echo escapeArchiveValue($item['approval_status']); ?></span></td>
										<td class="archive-details"><?php echo escapeArchiveValue($item['remarks']); ?></td>
									</tr>
								<?php endforeach; ?>
								<tr id="emptyState" hidden>
									<td colspan="8">No rejected requests found.</td>
								</tr>
							</tbody>
						</table>
					</div>

					<footer class="archive-table-footer staff-consistent-table-footer">
						<p class="archive-result-count staff-consistent-result-count" id="resultCount" aria-live="polite"></p>
						<div class="pagination staff-consistent-pagination" id="pagination" aria-label="Result pages"></div>
					</footer>
				</div>
			</section>
		</main>
	</div>

	<script>
		const archiveRows = Array.from(document.querySelectorAll('.archive-table tbody tr[data-type]'));
		const typeFilter = document.getElementById('typeFilter');
		const pagination = document.getElementById('pagination');
		const emptyState = document.getElementById('emptyState');
		const resultCount = document.getElementById('resultCount');
		const pageSize = 10;
		let currentPage = 1;

		function applyArchiveFilters() {
			const selectedType = typeFilter.value.toLocaleLowerCase();
			const filteredRows = archiveRows.filter(function (row) {
				return selectedType === 'all' || row.dataset.type.toLocaleLowerCase() === selectedType;
			});

			const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));
			currentPage = Math.min(currentPage, totalPages);
			const start = (currentPage - 1) * pageSize;
			const visibleRows = filteredRows.slice(start, start + pageSize);
			archiveRows.forEach(function (row) {
				row.hidden = !visibleRows.includes(row);
				if (!row.hidden) {
					row.querySelector('.archive-row-number').textContent = String(filteredRows.indexOf(row) + 1);
				}
			});
			emptyState.hidden = filteredRows.length !== 0;
			resultCount.textContent = filteredRows.length
				? 'Showing ' + (start + 1) + ' to ' + (start + visibleRows.length) + ' of ' + filteredRows.length + ' entries'
				: 'Showing 0 entries';
			renderArchivePagination(totalPages);
		}

		function renderArchivePagination(totalPages) {
			const firstPage = Math.max(1, Math.min(currentPage - 2, totalPages - 4));
			const lastPage = Math.min(totalPages, firstPage + 4);
			const buttons = [];
			for (let page = firstPage; page <= lastPage; page++) {
				buttons.push('<button class="page-btn' + (page === currentPage ? ' active' : '') + '" type="button" data-page="' + page + '"' + (page === currentPage ? ' aria-current="page"' : '') + '>' + page + '</button>');
			}
			pagination.innerHTML =
				'<button type="button" class="page-arrow" data-page="' + (currentPage - 1) + '" aria-label="Previous page"' + (currentPage === 1 ? ' disabled' : '') + '>Previous</button>' +
				buttons.join('') +
				'<button type="button" class="page-arrow" data-page="' + (currentPage + 1) + '" aria-label="Next page"' + (currentPage === totalPages ? ' disabled' : '') + '>Next</button>';

			pagination.querySelectorAll('button[data-page]').forEach(function (button) {
				button.addEventListener('click', function () {
					const targetPage = Number(button.dataset.page);
					if (targetPage >= 1 && targetPage <= totalPages) {
						currentPage = targetPage;
						applyArchiveFilters();
					}
				});
			});
		}

		typeFilter.addEventListener('change', function () {
			currentPage = 1;
			applyArchiveFilters();
		});
		applyArchiveFilters();
	</script>
</body>
</html>

