<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/session.php';
requireLogin();

if (($_SESSION['role'] ?? '') !== 'staff') {
    header('Location: /BMirk/auth/login.php');
    exit;
}

if (($_GET['view'] ?? '') === 'history') {
    header('Location: /BMirk/staff/posts/posts_history.php', true, 302);
    exit;
}

$page_title = 'Events';
$historyView = ($_GET['view'] ?? '') === 'history';
$historyStatuses = ['approved', 'published', 'completed'];
$eventStatuses = ['pending', 'approved', 'published'];
$allowedStatuses = $historyView ? $historyStatuses : $eventStatuses;
$search = trim((string) ($_GET['q'] ?? ''));
$statusFilter = (string) ($_GET['status'] ?? '');
$statusFilter = in_array($statusFilter, $allowedStatuses, true) ? $statusFilter : '';
$dateFrom = (string) ($_GET['from'] ?? '');
$dateTo = (string) ($_GET['to'] ?? '');
$page_title = $historyView ? 'Event History' : 'Events';

function escapeStaffEvent($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function staffEventDateIsValid(string $value): bool
{
    if ($value === '') {
        return false;
    }
    $date = DateTime::createFromFormat('!Y-m-d', $value);
    return $date instanceof DateTime && $date->format('Y-m-d') === $value;
}

if (!staffEventDateIsValid($dateFrom)) {
    $dateFrom = '';
}
if (!staffEventDateIsValid($dateTo)) {
    $dateTo = '';
}

$eventRows = [];
$eventsStatement = $databaseConnection->prepare(
    "SELECT e.id, e.title, e.description, e.event_date, e.start_time, e.end_time, e.location, e.status, e.created_at,
            (SELECT COUNT(*) FROM event_registrations er
             WHERE er.event_id = e.id AND er.status IN ('pending', 'approved')) AS registration_count,
            (SELECT COUNT(*) FROM event_attendance ea
             WHERE ea.event_id = e.id AND ea.attendance_status = 'present') AS attendance_count
     FROM events e
     WHERE ((? = 'history' AND e.status IN ('approved', 'published', 'completed') AND e.event_date < CURRENT_DATE)
            OR (? = 'events' AND e.status IN ('approved', 'published') AND e.event_date >= CURRENT_DATE)
            OR (? = 'events' AND e.status = 'pending' AND e.created_by = ?
                AND (SELECT latest_ar.status FROM approval_requests latest_ar
                     WHERE latest_ar.request_type = 'event' AND latest_ar.reference_id = e.id
                       AND latest_ar.requested_by = e.created_by
                     ORDER BY latest_ar.created_at DESC, latest_ar.id DESC LIMIT 1) = 'pending'))
       AND (? = '' OR e.title LIKE CONCAT('%', ?, '%')
            OR COALESCE(e.description, '') LIKE CONCAT('%', ?, '%')
            OR e.location LIKE CONCAT('%', ?, '%'))
       AND (? = '' OR e.status = ?)
       AND (? = '' OR e.event_date >= ?)
       AND (? = '' OR e.event_date <= ?)
     ORDER BY e.event_date DESC, e.start_time DESC, e.id DESC"
);
if (!$eventsStatement) {
    error_log('Unable to prepare Staff Events list query: ' . $databaseConnection->error);
    throw new RuntimeException('Unable to load events.');
}

$searchLike = $search;
$eventViewFilter = $historyView ? 'history' : 'events';
$eventViewFilterForHistory = $eventViewFilter;
$eventViewFilterForPending = $eventViewFilter;
$staffId = (int) ($_SESSION['user_id'] ?? 0);
$eventsStatement->bind_param(
    'sssissssssssss',
    $eventViewFilter,
    $eventViewFilterForHistory,
    $eventViewFilterForPending,
    $staffId,
    $search,
    $searchLike,
    $searchLike,
    $searchLike,
    $statusFilter,
    $statusFilter,
    $dateFrom,
    $dateFrom,
    $dateTo,
    $dateTo
);
if (!$eventsStatement->execute()) {
    error_log('Unable to execute Staff Events list query: ' . $eventsStatement->error);
    throw new RuntimeException('Unable to load events.');
}
$eventsResult = $eventsStatement->get_result();
while ($eventRow = $eventsResult->fetch_assoc()) {
    $eventRows[] = $eventRow;
}
$eventsStatement->close();

$requestedPage = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
$eventListPage = max(1, min(max(1, (int) ceil(count($eventRows) / 8)), $requestedPage ?: 1));
$selectedEventId = filter_input(INPUT_GET, 'event_id', FILTER_VALIDATE_INT);
$selectedIndex = null;
foreach ($eventRows as $index => $eventRow) {
    if ((int) $eventRow['id'] === $selectedEventId) {
        $selectedIndex = $index;
        break;
    }
}
$pageSize = 8;
$totalEvents = count($eventRows);
$totalPages = max(1, (int) ceil($totalEvents / $pageSize));
if ($selectedIndex !== null) {
    $eventListPage = (int) floor($selectedIndex / $pageSize) + 1;
}
$selectedEvent = $selectedIndex === null ? null : $eventRows[$selectedIndex];
$visibleEvents = array_slice($eventRows, ($eventListPage - 1) * $pageSize, $pageSize);

$eventTab = (string) ($_GET['tab'] ?? 'overview');
if (!in_array($eventTab, ['overview', 'registrations', 'attendance'], true)) {
    $eventTab = 'overview';
}

$eventParticipants = [];
if ($selectedEvent !== null) {
    $participantsStatement = $databaseConnection->prepare(
        "SELECT er.id AS registration_id, er.senior_id, er.status AS registration_status, er.registered_at,
                CONCAT_WS(' ', sp.first_name, NULLIF(sp.middle_name, ''), sp.last_name, NULLIF(sp.suffix, '')) AS senior_name,
                sp.senior_citizen_id, ea.attendance_status, ea.checked_in_at
         FROM event_registrations er
         JOIN senior_profiles sp ON sp.id = er.senior_id
         LEFT JOIN event_attendance ea ON ea.registration_id = er.id AND ea.senior_id = er.senior_id
         WHERE er.event_id = ? AND er.status IN ('pending', 'approved')
         ORDER BY sp.last_name, sp.first_name, er.registered_at"
    );
    if (!$participantsStatement) {
        error_log('Unable to prepare Staff Event registrations query: ' . $databaseConnection->error);
        throw new RuntimeException('Unable to load event registrations.');
    }
    $selectedEventIdForQuery = (int) $selectedEvent['id'];
    $participantsStatement->bind_param('i', $selectedEventIdForQuery);
    if (!$participantsStatement->execute()) {
        error_log('Unable to execute Staff Event registrations query: ' . $participantsStatement->error);
        throw new RuntimeException('Unable to load event registrations.');
    }
    $participantsResult = $participantsStatement->get_result();
    while ($participant = $participantsResult->fetch_assoc()) {
        $eventParticipants[] = $participant;
    }
    $participantsStatement->close();
}

$queryState = [
    'view' => $historyView ? 'history' : 'events',
    'q' => $search,
    'status' => $statusFilter,
    'from' => $dateFrom,
    'to' => $dateTo,
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo escapeStaffEvent($page_title); ?></title>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="/BMirk/staff/assets/table.css?v=18">
    <link rel="stylesheet" href="assets/posts.css?v=3">
</head>
<body>
    <div class="staff-layout">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <main class="staff-main">
            <?php include __DIR__ . '/../includes/header.php'; ?>
            <section class="staff-content staff-events-page">
                <header class="staff-events-heading">
                    <div>
                        <h1><?php echo $historyView ? 'Event History' : 'Events'; ?></h1>
                        <p><?php echo $historyView ? 'Review past approved events.' : 'View upcoming events and your requests awaiting review.'; ?></p>
                    </div>
                </header>

                <div class="staff-events-layout<?php echo $selectedEvent !== null ? ' has-selection' : ''; ?>">
                    <section class="staff-events-list-panel" aria-label="Event list">
                        <form class="staff-events-filters" method="get">
                            <?php if ($historyView): ?><input type="hidden" name="view" value="history"><?php endif; ?>
                            <div class="staff-event-search staff-search-field">
                                <label class="staff-search-label" for="eventSearch">Search</label>
                                <div class="staff-event-search-group">
                                    <input id="eventSearch" type="search" name="q" value="<?php echo escapeStaffEvent($search); ?>" placeholder="Search event title, venue, or description..." aria-label="Search events">
                                    <button class="staff-event-search-button" type="submit">Search</button>
                                </div>
                            </div>
                            <label>
                                <span>Status</span>
                                <select name="status">
                                    <option value=""><?php echo $historyView ? 'All statuses' : 'All event statuses'; ?></option>
                                    <?php foreach ($allowedStatuses as $status): ?>
                                        <option value="<?php echo escapeStaffEvent($status); ?>"<?php echo $statusFilter === $status ? ' selected' : ''; ?>><?php echo escapeStaffEvent(ucfirst($status)); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                            <label>
                                <span>Date From</span>
                                <input type="date" name="from" value="<?php echo escapeStaffEvent($dateFrom); ?>">
                            </label>
                            <label>
                                <span>Date To</span>
                                <input type="date" name="to" value="<?php echo escapeStaffEvent($dateTo); ?>">
                            </label>
                            <button type="submit">Filter</button>
                            <a class="staff-events-reset" href="/BMirk/staff/posts/events_history.php<?php echo $historyView ? '?view=history' : ''; ?>">Reset</a>
                        </form>

                        <div class="staff-events-table-wrap staff-consistent-table-wrap">
                            <table class="data-table staff-consistent-table staff-events-table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Event title</th>
                                        <th>Date &amp; time</th>
                                        <th>Venue</th>
                                        <th>Registrations</th>
                                        <th>Attendance</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!$visibleEvents): ?>
                                        <tr><td class="staff-events-empty" colspan="8">No events match these filters.</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($visibleEvents as $index => $event): ?>
                                            <?php
                                            $eventStatus = strtolower((string) $event['status']);
                                            $eventDate = new DateTimeImmutable((string) $event['event_date']);
                                            $eventDateLabel = $eventDate->format('M j, Y');
                                            $eventTimeLabel = date('g:i A', strtotime((string) $event['start_time']));
                                            $isSelected = $selectedEvent !== null && (int) $selectedEvent['id'] === (int) $event['id'];
                                            ?>
                                            <tr<?php echo $isSelected ? ' class="selected"' : ''; ?>>
                                                <td><?php echo ($eventListPage - 1) * $pageSize + $index + 1; ?></td>
                                                <td><strong><?php echo escapeStaffEvent($event['title']); ?></strong></td>
                                                <td><?php echo escapeStaffEvent($eventDateLabel); ?><small><?php echo escapeStaffEvent($eventTimeLabel); ?></small></td>
                                                <td><?php echo escapeStaffEvent($event['location']); ?></td>
                                                <td><?php echo (int) $event['registration_count']; ?></td>
                                                <td><?php echo (int) $event['attendance_count']; ?></td>
                                                <td><span class="staff-event-status <?php echo escapeStaffEvent($eventStatus); ?>"><?php echo escapeStaffEvent(ucfirst($eventStatus)); ?></span></td>
                                                <td><a class="staff-event-view" href="?<?php echo escapeStaffEvent(http_build_query($queryState + ['event_id' => (int) $event['id'], 'tab' => 'overview'])); ?>">View</a></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <footer class="staff-events-pagination staff-consistent-table-footer">
                            <p class="staff-consistent-result-count"><?php if ($totalEvents): ?>Showing <?php echo ($eventListPage - 1) * $pageSize + 1; ?> to <?php echo min($eventListPage * $pageSize, $totalEvents); ?> of <?php echo $totalEvents; ?> events<?php else: ?>Showing 0 events<?php endif; ?></p>
                            <?php if ($totalPages > 1): ?>
                                <nav class="staff-consistent-pagination" aria-label="Event pages">
                                    <?php for ($pageNumber = 1; $pageNumber <= $totalPages; $pageNumber++): ?>
                                        <a href="?<?php echo escapeStaffEvent(http_build_query($queryState + ['page' => $pageNumber])); ?>"<?php echo $pageNumber === $eventListPage ? ' aria-current="page"' : ''; ?>><?php echo $pageNumber; ?></a>
                                    <?php endfor; ?>
                                </nav>
                            <?php endif; ?>
                        </footer>
                    </section>

                    <?php if ($selectedEvent !== null): ?>
                        <aside class="staff-event-detail" aria-label="Selected event details">
                            <?php
                            $selectedEventStatus = strtolower((string) $selectedEvent['status']);
                            $detailBase = $queryState + ['event_id' => (int) $selectedEvent['id']];
                            ?>
                            <header class="staff-event-detail-heading">
                                <div>
                                    <h2><?php echo escapeStaffEvent($selectedEvent['title']); ?></h2>
                                    <span class="staff-event-status <?php echo escapeStaffEvent($selectedEventStatus); ?>"><?php echo escapeStaffEvent(ucfirst($selectedEventStatus)); ?></span>
                                </div>
                                <a class="staff-event-detail-close" href="?<?php echo escapeStaffEvent(http_build_query($queryState + ['page' => $eventListPage])); ?>" aria-label="Close event details">&times;</a>
                            </header>
                            <nav class="staff-event-tabs" aria-label="Event information">
                                <a href="?<?php echo escapeStaffEvent(http_build_query($detailBase + ['tab' => 'overview'])); ?>"<?php echo $eventTab === 'overview' ? ' aria-current="page"' : ''; ?>>Overview</a>
                                <a href="?<?php echo escapeStaffEvent(http_build_query($detailBase + ['tab' => 'registrations'])); ?>"<?php echo $eventTab === 'registrations' ? ' aria-current="page"' : ''; ?>>Registrations <span><?php echo count($eventParticipants); ?></span></a>
                                <a href="?<?php echo escapeStaffEvent(http_build_query($detailBase + ['tab' => 'attendance'])); ?>"<?php echo $eventTab === 'attendance' ? ' aria-current="page"' : ''; ?>>Attendance</a>
                            </nav>

                            <?php if ($eventTab === 'overview'): ?>
                                <section class="staff-event-overview">
                                    <h3>Event details</h3>
                                    <dl>
                                        <div><dt>Event title</dt><dd><?php echo escapeStaffEvent($selectedEvent['title']); ?></dd></div>
                                        <div><dt>Date &amp; time</dt><dd><?php echo escapeStaffEvent((new DateTimeImmutable((string) $selectedEvent['event_date']))->format('F j, Y')); ?><br><?php echo escapeStaffEvent(date('g:i A', strtotime((string) $selectedEvent['start_time']))); ?><?php if (!empty($selectedEvent['end_time'])): ?> - <?php echo escapeStaffEvent(date('g:i A', strtotime((string) $selectedEvent['end_time']))); ?><?php endif; ?></dd></div>
                                        <div><dt>Venue</dt><dd><?php echo escapeStaffEvent($selectedEvent['location']); ?></dd></div>
                                        <div><dt>Description</dt><dd><?php echo nl2br(escapeStaffEvent($selectedEvent['description'] ?: 'No description provided.')); ?></dd></div>
                                    </dl>
                                </section>
                                <div class="staff-event-stats">
                                    <div><strong><?php echo (int) $selectedEvent['registration_count']; ?></strong><span>Registrations</span></div>
                                    <div><strong><?php echo (int) $selectedEvent['attendance_count']; ?></strong><span>Attended</span></div>
                                </div>
                            <?php else: ?>
                                <section class="staff-event-participants">
                                    <h3><?php echo $eventTab === 'registrations' ? 'Registrations' : 'Attendance'; ?></h3>
                                    <?php if (!$eventParticipants): ?>
                                        <p class="staff-event-empty">No registrations for this event yet.</p>
                                    <?php else: ?>
                                        <div class="staff-event-participants-table-wrap">
                                            <table class="staff-event-participants-table">
                                                <thead><tr><th>Senior</th><?php if ($eventTab === 'registrations'): ?><th>Status</th><th>Registered</th><?php else: ?><th>Attendance</th><th>Checked in</th><?php endif; ?></tr></thead>
                                                <tbody>
                                                    <?php foreach ($eventParticipants as $participant): ?>
                                                        <tr>
                                                            <td><strong><?php echo escapeStaffEvent($participant['senior_name']); ?></strong><small><?php echo escapeStaffEvent($participant['senior_citizen_id']); ?></small></td>
                                                            <?php if ($eventTab === 'registrations'): ?>
                                                                <td><?php echo escapeStaffEvent(ucfirst((string) $participant['registration_status'])); ?></td>
                                                                <td><?php echo escapeStaffEvent(date('M j, Y', strtotime((string) $participant['registered_at']))); ?></td>
                                                            <?php else: ?>
                                                                <td><?php echo escapeStaffEvent($participant['attendance_status'] ? ucfirst((string) $participant['attendance_status']) : 'Not recorded'); ?></td>
                                                                <td><?php echo escapeStaffEvent($participant['checked_in_at'] ? date('M j, g:i A', strtotime((string) $participant['checked_in_at'])) : '—'); ?></td>
                                                            <?php endif; ?>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </section>
                            <?php endif; ?>
                        </aside>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </div>
</body>
</html>
