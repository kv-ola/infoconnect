<?php
header('Location: /BMirk/staff/settings/settings.php?tab=security', true, 302);
exit;
