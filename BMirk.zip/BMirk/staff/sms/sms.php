<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/activity_log.php';
require_once __DIR__ . '/../../config/sms_gateway.php';
requireLogin();

if (($_SESSION['role'] ?? '') !== 'staff') {
	header('Location: /BMirk/auth/login.php');
	exit;
}

$page_title = 'Send SMS';
$staffId = (int) ($_SESSION['user_id'] ?? 0);
$seniors = [];
$barangays = [];
$recentMessages = [];
$pageError = '';
$previewResult = null;
$smsGatewayConfig = philSmsConfig();
$smsGatewayConfigured = $smsGatewayConfig['api_token'] !== '';
$flash = $_SESSION['staff_sms_flash'] ?? null;
unset($_SESSION['staff_sms_flash']);

function staffSmsEscape($value): string
{
	return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['staff_sms_csrf'])) {
	$_SESSION['staff_sms_csrf'] = bin2hex(random_bytes(32));
}

$form = [
	'recipient_type' => 'individual',
	'senior_id' => '',
	'category_barangay' => '',
	'category_sex' => '',
	'age_min' => '',
	'age_max' => '',
	'senior_ids' => [],
	'sms_type' => 'general',
	'message' => '',
];

try {
	$seniorResult = $databaseConnection->query(
		"SELECT id, senior_citizen_id, first_name, middle_name, last_name, barangay, sex, birth_date, contact_number
		 FROM senior_profiles
		 WHERE status = 'active' AND approval_status = 'approved'
		   AND contact_number IS NOT NULL AND TRIM(contact_number) <> ''
		 ORDER BY last_name, first_name"
	);
	while ($senior = $seniorResult->fetch_assoc()) {
		$seniors[] = $senior;
	}
	$barangayResult = $databaseConnection->query(
		"SELECT DISTINCT barangay FROM senior_profiles
		 WHERE status = 'active' AND approval_status = 'approved'
		   AND contact_number IS NOT NULL AND TRIM(contact_number) <> ''
		   AND barangay IS NOT NULL AND TRIM(barangay) <> ''
		 ORDER BY barangay"
	);
	while ($barangay = $barangayResult->fetch_assoc()) {
		$barangays[] = $barangay['barangay'];
	}

	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		$recipientType = $_POST['recipient_type'] ?? '';
		$seniorIdInput = $_POST['senior_id'] ?? '';
		$categoryBarangayInput = $_POST['category_barangay'] ?? '';
		$categorySexInput = $_POST['category_sex'] ?? '';
		$ageMinInput = $_POST['age_min'] ?? '';
		$ageMaxInput = $_POST['age_max'] ?? '';
		$seniorIdsInput = $_POST['senior_ids'] ?? [];
		$smsTypeInput = $_POST['sms_type'] ?? '';
		$messageInput = $_POST['message'] ?? '';
		$form['recipient_type'] = is_string($recipientType) ? $recipientType : 'individual';
		$form['senior_id'] = is_string($seniorIdInput) ? $seniorIdInput : '';
		$form['category_barangay'] = is_string($categoryBarangayInput) ? $categoryBarangayInput : '';
		$form['category_sex'] = is_string($categorySexInput) ? $categorySexInput : '';
		$form['age_min'] = is_string($ageMinInput) ? trim($ageMinInput) : '';
		$form['age_max'] = is_string($ageMaxInput) ? trim($ageMaxInput) : '';
		$form['senior_ids'] = is_array($seniorIdsInput) ? array_values(array_filter($seniorIdsInput, 'is_string')) : [];
		$form['sms_type'] = is_string($smsTypeInput) ? $smsTypeInput : 'general';
		$form['message'] = is_string($messageInput) ? trim($messageInput) : '';
		$intent = $_POST['intent'] ?? '';
		$submittedToken = $_POST['csrf_token'] ?? '';
		$errors = [];

		if (!is_string($submittedToken) || !hash_equals($_SESSION['staff_sms_csrf'], $submittedToken)) {
			$errors[] = 'This form has expired. Refresh the page and try again.';
		}
		if (!in_array($form['recipient_type'], ['individual', 'barangay', 'selected', 'all_active'], true)) {
			$errors[] = 'Choose a valid recipient type.';
		}
		if (!in_array($form['sms_type'], ['event', 'announcement', 'important', 'general'], true)) {
			$errors[] = 'Choose a valid message category.';
		}
		if ($form['message'] === '' || mb_strlen($form['message'], 'UTF-8') > 160) {
			$errors[] = 'Enter a message from 1 to 160 characters.';
		}

		$recipientRows = [];
		if (!$errors) {
			switch ($form['recipient_type']) {
				case 'individual':
					$selectedId = filter_var($form['senior_id'], FILTER_VALIDATE_INT);
					if ($selectedId === false || !$selectedId) {
						$errors[] = 'Select a senior citizen.';
					} else {
						$recipientStatement = $databaseConnection->prepare(
							"SELECT id, contact_number FROM senior_profiles WHERE id = ? AND status = 'active' AND approval_status = 'approved' AND contact_number IS NOT NULL AND TRIM(contact_number) <> ''"
						);
						$recipientStatement->bind_param('i', $selectedId);
						$recipientStatement->execute();
						$recipientRows = $recipientStatement->get_result()->fetch_all(MYSQLI_ASSOC);
						$recipientStatement->close();
					}
					break;
				case 'barangay':
					if ($form['category_barangay'] !== '' && !in_array($form['category_barangay'], $barangays, true)) {
						$errors[] = 'Choose a valid barangay category.';
					}
					if ($form['category_sex'] !== '' && !in_array($form['category_sex'], ['male', 'female'], true)) {
						$errors[] = 'Choose a valid sex category.';
					}
					$hasAgeRange = $form['age_min'] !== '' || $form['age_max'] !== '';
					$ageMin = $form['age_min'] === '' ? null : filter_var($form['age_min'], FILTER_VALIDATE_INT);
					$ageMax = $form['age_max'] === '' ? null : filter_var($form['age_max'], FILTER_VALIDATE_INT);
					if ($hasAgeRange && ($ageMin === null || $ageMin === false || $ageMax === null || $ageMax === false || $ageMin < 60 || $ageMax > 130 || $ageMin > $ageMax)) {
						$errors[] = 'Enter a valid age range from 60 to 130, with the minimum no greater than the maximum.';
					}
					if ($form['category_barangay'] === '' && $form['category_sex'] === '' && !$hasAgeRange) {
						$errors[] = 'Choose at least one category filter.';
					}
					if (!$errors) {
						$recipientRows = array_values(array_filter($seniors, static function ($senior) use ($form, $ageMin, $ageMax) {
							if ($form['category_barangay'] !== '' && $senior['barangay'] !== $form['category_barangay']) return false;
							if ($form['category_sex'] !== '' && $senior['sex'] !== $form['category_sex']) return false;
							if ($ageMin !== null && $ageMax !== null) {
								$birthDate = new DateTimeImmutable($senior['birth_date']);
								$age = (int) $birthDate->diff(new DateTimeImmutable('today'))->format('%y');
								if ($age < $ageMin || $age > $ageMax) return false;
							}
							return true;
						}));
					}
					break;
				case 'selected':
					$selectedIds = array_values(array_unique(array_filter(array_map('intval', $form['senior_ids']), static fn ($id) => $id > 0)));
					if (!$selectedIds) {
						$errors[] = 'Select at least one senior citizen.';
					} else {
						$placeholders = implode(',', array_fill(0, count($selectedIds), '?'));
						$recipientQuery = "SELECT id, contact_number FROM senior_profiles WHERE id IN ($placeholders) AND status = 'active' AND approval_status = 'approved' AND contact_number IS NOT NULL AND TRIM(contact_number) <> ''";
						$recipientStatement = $databaseConnection->prepare($recipientQuery);
						$recipientTypes = str_repeat('i', count($selectedIds));
						$recipientStatement->bind_param($recipientTypes, ...$selectedIds);
						$recipientStatement->execute();
						$recipientRows = $recipientStatement->get_result()->fetch_all(MYSQLI_ASSOC);
						$recipientStatement->close();
					}
					break;
				case 'all_active':
					$recipientRows = array_map(static fn ($senior) => ['id' => $senior['id'], 'contact_number' => $senior['contact_number']], $seniors);
					break;
			}
			if (!$recipientRows && !$errors) {
				$errors[] = 'No active senior recipients with contact numbers were found.';
			}
		}

		if ($errors) {
			$pageError = implode(' ', $errors);
		} elseif ($intent === 'send') {
			if (!$smsGatewayConfigured) {
				$pageError = 'SMS sending is not configured yet. Set PHILSMS_API_TOKEN in the web server environment, then restart Apache.';
			} else {
				$recipientsByNumber = [];
				$invalidRecipientRows = [];
				foreach ($recipientRows as $recipient) {
					$phoneNumber = normalizePhilippineSmsNumber((string) $recipient['contact_number']);
					if ($phoneNumber === '') {
						$invalidRecipientRows[] = ['recipient' => $recipient, 'error' => 'Invalid Philippine mobile number.'];
						continue;
					}
					$recipientsByNumber[$phoneNumber][] = $recipient;
				}

				$databaseConnection->begin_transaction();
				try {
					$recipientTypeForDb = $form['recipient_type'] === 'all_active' ? 'all_active' : 'selected';
					$sendingStatus = 'sending';
					$insertMessage = $databaseConnection->prepare(
						'INSERT INTO sms_messages (created_by, message, sms_type, recipient_type, status) VALUES (?, ?, ?, ?, ?)'
					);
					$insertMessage->bind_param('issss', $staffId, $form['message'], $form['sms_type'], $recipientTypeForDb, $sendingStatus);
					$insertMessage->execute();
					$messageId = (int) $databaseConnection->insert_id;
					$insertMessage->close();

					$insertRecipient = $databaseConnection->prepare(
						'INSERT INTO sms_recipients (sms_message_id, senior_id, contact_number, delivery_status, error_message) VALUES (?, ?, ?, ?, ?)'
					);
					foreach ($recipientsByNumber as $phoneNumber => $group) {
						foreach ($group as $recipient) {
							$recipientId = (int) $recipient['id'];
							$deliveryStatus = 'pending';
							$deliveryError = null;
							$insertRecipient->bind_param('iisss', $messageId, $recipientId, $phoneNumber, $deliveryStatus, $deliveryError);
							$insertRecipient->execute();
						}
					}
					foreach ($invalidRecipientRows as $invalid) {
						$recipientId = (int) $invalid['recipient']['id'];
						$contactNumber = trim((string) $invalid['recipient']['contact_number']);
						$deliveryStatus = 'failed';
						$deliveryError = $invalid['error'];
						$insertRecipient->bind_param('iisss', $messageId, $recipientId, $contactNumber, $deliveryStatus, $deliveryError);
						$insertRecipient->execute();
					}
					$insertRecipient->close();
					$databaseConnection->commit();
				} catch (Throwable $exception) {
					$databaseConnection->rollback();
					throw $exception;
				}

				$deliveryByNumber = [];
				$phoneNumbers = array_keys($recipientsByNumber);
				foreach (array_chunk($phoneNumbers, 1000) as $numberBatch) {
					try {
						$gatewayResponses = sendPhilSmsBatch($numberBatch, $form['message'], $smsGatewayConfig);
						foreach ($gatewayResponses as $gatewayResponse) {
							$responseNumber = normalizePhilippineSmsNumber((string) ($gatewayResponse['recipient'] ?? ''));
							if ($responseNumber === '' && count($numberBatch) === 1) {
								$responseNumber = $numberBatch[0];
							}
							if ($responseNumber === '' || !in_array($responseNumber, $numberBatch, true)) {
								continue;
							}
							$providerStatus = strtolower((string) ($gatewayResponse['status'] ?? ''));
							$isAccepted = in_array($providerStatus, ['queued', 'pending', 'sent'], true);
							$deliveryByNumber[$responseNumber] = [
								'status' => $isAccepted ? 'sent' : 'failed',
								'error' => $isAccepted ? null : (string) ($gatewayResponse['message'] ?? ('PhilSMS status: ' . ($providerStatus ?: 'unknown'))),
							];
						}
					} catch (Throwable $exception) {
						$batchError = mb_substr($exception->getMessage(), 0, 500, 'UTF-8');
						foreach ($numberBatch as $phoneNumber) {
							$deliveryByNumber[$phoneNumber] = ['status' => 'failed', 'error' => $batchError];
						}
					}
					foreach ($numberBatch as $phoneNumber) {
						if (!isset($deliveryByNumber[$phoneNumber])) {
							$deliveryByNumber[$phoneNumber] = ['status' => 'failed', 'error' => 'PhilSMS response did not include this recipient.'];
						}
					}
				}

				$acceptedRecipientCount = 0;
				$failedRecipientCount = count($invalidRecipientRows);
				$databaseConnection->begin_transaction();
				try {
					$updateRecipient = $databaseConnection->prepare(
						"UPDATE sms_recipients SET delivery_status = ?, sent_at = CASE WHEN ? = 'sent' THEN CURRENT_TIMESTAMP ELSE NULL END, error_message = ? WHERE sms_message_id = ? AND senior_id = ?"
					);
					foreach ($recipientsByNumber as $phoneNumber => $group) {
						$delivery = $deliveryByNumber[$phoneNumber] ?? ['status' => 'failed', 'error' => 'No delivery result was received.'];
						foreach ($group as $recipient) {
							$recipientId = (int) $recipient['id'];
							$deliveryStatus = $delivery['status'];
							$deliveryError = $delivery['error'];
							$updateRecipient->bind_param('sssii', $deliveryStatus, $deliveryStatus, $deliveryError, $messageId, $recipientId);
							$updateRecipient->execute();
							if ($deliveryStatus === 'sent') $acceptedRecipientCount++;
							else $failedRecipientCount++;
						}
					}
					$updateRecipient->close();
					$finalMessageStatus = $acceptedRecipientCount > 0 ? 'sent' : 'failed';
					$updateMessage = $databaseConnection->prepare(
						"UPDATE sms_messages SET status = ?, sent_at = CASE WHEN ? = 'sent' THEN CURRENT_TIMESTAMP ELSE NULL END WHERE id = ?"
					);
					$updateMessage->bind_param('ssi', $finalMessageStatus, $finalMessageStatus, $messageId);
					$updateMessage->execute();
					$updateMessage->close();
					$activityDescription = 'PhilSMS accepted ' . $acceptedRecipientCount . ' of ' . count($recipientRows) . ' SMS recipient(s); ' . $failedRecipientCount . ' failed.';
					writeActivityLog($databaseConnection, $staffId, 'send', 'SMS', $activityDescription, $messageId);
					$databaseConnection->commit();
				} catch (Throwable $exception) {
					$databaseConnection->rollback();
					throw $exception;
				}

				$wasAccepted = $acceptedRecipientCount > 0;
				$_SESSION['staff_sms_flash'] = [
					'type' => $wasAccepted ? 'sent' : 'failed',
					'title' => $wasAccepted ? 'Message Submitted' : 'SMS Delivery Failed',
					'message' => $wasAccepted
						? 'PhilSMS accepted ' . $acceptedRecipientCount . ' of ' . count($recipientRows) . ' recipient(s). Accepted messages enter the provider delivery queue; delivery to each phone can still depend on the mobile network.'
						: 'PhilSMS did not accept any messages. ' . $failedRecipientCount . ' recipient(s) failed. Review the error details in SMS history.',
				];
				$_SESSION['staff_sms_csrf'] = bin2hex(random_bytes(32));
				header('Location: /BMirk/staff/sms/sms.php', true, 303);
				exit;
			}
		} elseif ($intent === 'preview') {
			$previewResult = ['count' => count($recipientRows)];
		}
	}

	$recentStatement = $databaseConnection->query(
		"SELECT m.id, m.message, m.sms_type, m.recipient_type, m.status, m.created_at,
		        COUNT(r.id) AS recipient_count,
		        SUBSTRING_INDEX(GROUP_CONCAT(DISTINCT CONCAT(sp.first_name, ' ', sp.last_name) ORDER BY sp.last_name, sp.first_name SEPARATOR ', '), ', ', 3) AS recipient_names
		 FROM sms_messages m
		 LEFT JOIN sms_recipients r ON r.sms_message_id = m.id
		 LEFT JOIN senior_profiles sp ON sp.id = r.senior_id
		 WHERE m.created_by = " . $staffId . "
		 GROUP BY m.id
		 ORDER BY m.created_at DESC, m.id DESC
		 LIMIT 5"
	);
	while ($row = $recentStatement->fetch_assoc()) {
		$recentMessages[] = $row;
	}
} catch (Throwable $exception) {
	error_log('Staff SMS page error: ' . $exception->getMessage());
	if ($pageError === '') {
		$pageError = 'The SMS page could not load its data. Please refresh the page or contact an administrator.';
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo staffSmsEscape($page_title); ?> | InfoConnect</title>
	<link rel="stylesheet" href="../home.css">

	<link rel="stylesheet" href="sms.css?v=5">
</head>
<body>
	<div class="staff-layout">
		<?php include __DIR__ . '/../includes/sidebar.php'; ?>
		<main class="staff-main">
			<?php include __DIR__ . '/../includes/header.php'; ?>
			<section class="staff-content sms-page">
				<header class="sms-page-heading"><div><div><h1>Send SMS</h1><p>Send messages to senior citizens for events, announcements, and other important updates.</p></div></div></header>
				<?php if ($pageError !== ''): ?><div class="sms-alert error" role="alert"><?php echo staffSmsEscape($pageError); ?></div><?php endif; ?>
				<?php if (!$smsGatewayConfigured): ?><div class="sms-alert gateway-setup" role="status">SMS delivery is not set up yet. An administrator must configure the PhilSMS API token in the web server environment before messages can be sent.</div><?php endif; ?>
				<?php if (is_array($flash)): ?><div class="sms-alert <?php echo staffSmsEscape($flash['type'] ?? ''); ?>" role="status"><?php echo staffSmsEscape($flash['title'] ?? ''); ?> — <?php echo staffSmsEscape($flash['message'] ?? ''); ?></div><?php endif; ?>

				<div class="sms-workspace">
					<section class="sms-card sms-compose-card" aria-labelledby="sms-compose-title">
						<h2 class="sms-form-title" id="sms-compose-title">Recipient Type</h2>
						<form method="post" id="smsComposeForm">
							<input type="hidden" name="csrf_token" value="<?php echo staffSmsEscape($_SESSION['staff_sms_csrf']); ?>">
							<input type="hidden" name="intent" id="smsIntent" value="preview">
							<div class="sms-recipient-types" role="radiogroup" aria-label="Recipient type">
								<label class="sms-recipient-option"><input type="radio" name="recipient_type" value="individual" <?php echo $form['recipient_type'] === 'individual' ? 'checked' : ''; ?>><strong>Individual</strong><small>Send to one senior</small></label>
								<label class="sms-recipient-option"><input type="radio" name="recipient_type" value="barangay" <?php echo $form['recipient_type'] === 'barangay' ? 'checked' : ''; ?>><strong>By Category</strong><small>Group seniors by barangay</small></label>
								<label class="sms-recipient-option"><input type="radio" name="recipient_type" value="selected" <?php echo $form['recipient_type'] === 'selected' ? 'checked' : ''; ?>><strong>Selected</strong><small>Send to chosen seniors</small></label>
								<label class="sms-recipient-option"><input type="radio" name="recipient_type" value="all_active" <?php echo $form['recipient_type'] === 'all_active' ? 'checked' : ''; ?>><strong>All Seniors</strong><small>Send to all active seniors</small></label>
							</div>
							<div class="sms-form-fields">
								<div class="sms-field sms-audience-field" data-audience="individual">
									<label for="smsSeniorSearch">Search Senior</label>
									<div class="sms-search-controls"><input id="smsSeniorSearch" type="search" placeholder="Search by name or senior ID"><button class="sms-button secondary" type="button" id="smsSeniorSearchButton">Search</button></div>
									<input id="smsSenior" type="hidden" name="senior_id" value="<?php echo staffSmsEscape($form['senior_id']); ?>">
									<div class="sms-search-results" id="smsSeniorResults">
										<p class="sms-search-placeholder">Search by name or senior ID, then select a senior.</p>
										<?php foreach ($seniors as $senior): $seniorAge = (int) (new DateTimeImmutable($senior['birth_date']))->diff(new DateTimeImmutable('today'))->format('%y'); $seniorFullName = trim($senior['first_name'] . ' ' . $senior['middle_name'] . ' ' . $senior['last_name']); ?>
											<button class="sms-search-result sms-individual-result" type="button" data-senior-id="<?php echo (int) $senior['id']; ?>" data-phone="<?php echo staffSmsEscape($senior['contact_number']); ?>" data-name="<?php echo staffSmsEscape($seniorFullName); ?>" data-card-id="<?php echo staffSmsEscape($senior['senior_citizen_id']); ?>" data-search="<?php echo staffSmsEscape(strtolower($seniorFullName . ' ' . $senior['senior_citizen_id'])); ?>" data-barangay="<?php echo staffSmsEscape($senior['barangay']); ?>" data-sex="<?php echo staffSmsEscape($senior['sex']); ?>" data-age="<?php echo $seniorAge; ?>" hidden><?php echo staffSmsEscape($seniorFullName . ' (' . $senior['senior_citizen_id'] . ')'); ?></button>
										<?php endforeach; ?>
										<p class="sms-no-search-results" hidden>No matching seniors found.</p>
									</div>
									<p class="sms-selected-summary" id="smsIndividualSummary"><?php echo $form['senior_id'] !== '' ? 'Selected senior will appear here.' : 'Choose a senior from the search results.'; ?></p>
								</div>
								<div class="sms-field sms-audience-field sms-category-filters" data-audience="barangay">
									<strong class="sms-category-title">Choose one or more filters</strong>
									<div class="sms-category-grid">
										<div><label for="smsCategoryBarangay">Barangay</label><select id="smsCategoryBarangay" name="category_barangay"><option value="">Any barangay</option><?php foreach ($barangays as $barangay): ?><option value="<?php echo staffSmsEscape($barangay); ?>" <?php echo $form['category_barangay'] === $barangay ? 'selected' : ''; ?>><?php echo staffSmsEscape($barangay); ?></option><?php endforeach; ?></select></div>
										<div><label for="smsCategorySex">Sex</label><select id="smsCategorySex" name="category_sex"><option value="">Any sex</option><option value="female" <?php echo $form['category_sex'] === 'female' ? 'selected' : ''; ?>>Female</option><option value="male" <?php echo $form['category_sex'] === 'male' ? 'selected' : ''; ?>>Male</option></select></div>
										<fieldset class="sms-age-range"><legend>Age range</legend><label class="visually-hidden" for="smsAgeMin">Minimum age</label><input id="smsAgeMin" name="age_min" type="number" min="60" max="130" value="<?php echo staffSmsEscape($form['age_min']); ?>" placeholder="Min"><span>to</span><label class="visually-hidden" for="smsAgeMax">Maximum age</label><input id="smsAgeMax" name="age_max" type="number" min="60" max="130" value="<?php echo staffSmsEscape($form['age_max']); ?>" placeholder="Max"></fieldset>
									</div>
									<small>Filters combine. Choose a barangay, sex, age range, or a combination.</small>
								</div>
								<div class="sms-field sms-audience-field sms-selected-picker" data-audience="selected">
									<label for="smsSelectedSearch">Search and select seniors</label>
									<div class="sms-search-controls"><input id="smsSelectedSearch" type="search" placeholder="Search by name or senior ID"><button class="sms-button secondary" type="button" id="smsSelectedSearchButton">Search</button></div>
									<div class="sms-select-results" id="smsSelectedResults">
										<p class="sms-search-placeholder">Search by name or senior ID to show seniors you can select.</p>
										<?php foreach ($seniors as $senior): $seniorAge = (int) (new DateTimeImmutable($senior['birth_date']))->diff(new DateTimeImmutable('today'))->format('%y'); $seniorFullName = trim($senior['first_name'] . ' ' . $senior['middle_name'] . ' ' . $senior['last_name']); ?>
											<label class="sms-select-result" data-search="<?php echo staffSmsEscape(strtolower($seniorFullName . ' ' . $senior['senior_citizen_id'])); ?>" hidden><input type="checkbox" name="senior_ids[]" value="<?php echo (int) $senior['id']; ?>" data-name="<?php echo staffSmsEscape($seniorFullName); ?>" data-card-id="<?php echo staffSmsEscape($senior['senior_citizen_id']); ?>" data-phone="<?php echo staffSmsEscape($senior['contact_number']); ?>" data-barangay="<?php echo staffSmsEscape($senior['barangay']); ?>" data-sex="<?php echo staffSmsEscape($senior['sex']); ?>" data-age="<?php echo $seniorAge; ?>" <?php echo in_array((string) $senior['id'], $form['senior_ids'], true) ? 'checked' : ''; ?>><span><?php echo staffSmsEscape($seniorFullName . ' (' . $senior['senior_citizen_id'] . ')'); ?></span></label>
										<?php endforeach; ?>
										<p class="sms-no-search-results" hidden>No matching seniors found.</p>
									</div>
									<p class="sms-selected-summary" id="smsSelectedSummary">No seniors selected.</p>
								</div>
								<div class="sms-recipient-side-fields">
									<div class="sms-field sms-contact-field"><label for="smsContact">Contact Number</label><input id="smsContact" type="text" readonly placeholder="Contact number is based on the senior's profile."><small id="smsContactHint">Only active seniors with a contact number can receive messages.</small></div>
									<div class="sms-field sms-type-field"><label for="smsType">Message Category</label><select id="smsType" name="sms_type"><option value="general" <?php echo $form['sms_type'] === 'general' ? 'selected' : ''; ?>>General Update</option><option value="event" <?php echo $form['sms_type'] === 'event' ? 'selected' : ''; ?>>Event</option><option value="announcement" <?php echo $form['sms_type'] === 'announcement' ? 'selected' : ''; ?>>Announcement</option><option value="important" <?php echo $form['sms_type'] === 'important' ? 'selected' : ''; ?>>Important Notice</option></select></div>
								</div>
								<div class="sms-field sms-message-field"><label for="smsMessage">Message</label><textarea id="smsMessage" name="message" rows="4" maxlength="160" required placeholder="Type your message here..."><?php echo staffSmsEscape($form['message']); ?></textarea><div class="sms-message-meta"><small>Keep your message to 160 characters.</small><span>Characters: <b id="smsCharacterCount">0</b> / 160</span></div></div>
							</div>
							<div class="sms-form-actions"><button class="sms-button secondary" type="reset" id="smsCancel">Cancel</button><button class="sms-button primary" type="submit" id="smsPreviewButton">Preview &amp; Send</button></div>
						</form>
					</section>

					<section class="sms-card sms-history-card" aria-labelledby="sms-history-title">
						<header class="sms-history-heading"><h2 id="sms-history-title">Recent SMS Messages</h2><a href="/BMirk/staff/monitoring/reports.php?type=sms">View All</a></header>
						<div class="sms-table-wrap"><table class="sms-history-table"><thead><tr><th>Date</th><th>Recipient(s)</th><th>Message Preview</th><th>Status</th></tr></thead><tbody>
							<?php if (!$recentMessages): ?><tr><td colspan="4" class="sms-empty">No SMS messages have been sent yet.</td></tr><?php else: foreach ($recentMessages as $message):
								$recipientLabel = $message['recipient_type'] === 'all_active' ? 'All Active Seniors' : ($message['recipient_count'] === '1' ? ($message['recipient_names'] ?: '1 recipient') : (($message['recipient_names'] ?: 'Selected Seniors') . ' (' . (int) $message['recipient_count'] . ' recipients)'));
								$statusLabel = ucfirst($message['status']);
							?>
							<tr><td><?php echo staffSmsEscape(date('M j, Y g:i A', strtotime($message['created_at']))); ?></td><td><?php echo staffSmsEscape($recipientLabel); ?></td><td title="<?php echo staffSmsEscape($message['message']); ?>"><?php echo staffSmsEscape(mb_strimwidth($message['message'], 0, 55, '...', 'UTF-8')); ?></td><td><span class="sms-status <?php echo staffSmsEscape($message['status']); ?>"><?php echo staffSmsEscape($statusLabel); ?></span></td></tr>
							<?php endforeach; endif; ?></tbody></table></div>
					</section>
				</div>
			</section>
		</main>
	</div>

	<div class="sms-modal-backdrop" id="smsPreviewModal" hidden>
		<section class="sms-modal" role="dialog" aria-modal="true" aria-labelledby="smsPreviewTitle">
			<header><div><h2 id="smsPreviewTitle">Preview Message</h2><p>Please review the details before sending.</p></div><button type="button" class="sms-modal-close" data-close-preview>Close</button></header>
			<dl class="sms-preview-details"><div><dt>Recipient Type</dt><dd id="previewRecipientType"></dd></div><div><dt>Recipients</dt><dd id="previewRecipientNames"></dd></div><div><dt>Contact Number(s)</dt><dd id="previewContact"></dd></div><div><dt>Message</dt><dd id="previewMessageText"></dd></div></dl>
						<footer><button type="button" class="sms-button secondary" data-close-preview>Back</button><button type="button" class="sms-button primary" id="smsConfirmSend">Send SMS</button></footer>
		</section>
	</div>

	<?php if (is_array($flash)): ?>
	<div class="sms-modal-backdrop" id="smsResultModal">
		<section class="sms-modal sms-result-modal <?php echo staffSmsEscape($flash['type'] ?? 'failed'); ?>" role="dialog" aria-modal="true" aria-labelledby="smsResultTitle">
			<h2 id="smsResultTitle"><?php echo staffSmsEscape($flash['title'] ?? 'SMS delivery failed'); ?></h2><p><?php echo staffSmsEscape($flash['message'] ?? ''); ?></p><button type="button" class="sms-button primary" data-close-result>OK</button>
		</section>
	</div>
	<?php endif; ?>

	<script>
	(function () {
		const form = document.getElementById('smsComposeForm');
		const message = document.getElementById('smsMessage');
		const count = document.getElementById('smsCharacterCount');
		const modal = document.getElementById('smsPreviewModal');
		const intent = document.getElementById('smsIntent');
		const audienceRadios = Array.from(document.querySelectorAll('input[name="recipient_type"]'));
		const seniorSelect = document.getElementById('smsSenior');
		const phone = document.getElementById('smsContact');
		const contactHint = document.getElementById('smsContactHint');
		const labels = { individual: 'Individual', barangay: 'By Category', selected: 'Selected', all_active: 'All Seniors' };

		function selectedAudience() {
			return audienceRadios.find(function (radio) { return radio.checked; })?.value || 'individual';
		}
		function updateAudience() {
			const active = selectedAudience();
			document.querySelectorAll('.sms-audience-field').forEach(function (field) {
				const show = field.dataset.audience === active;
				field.hidden = !show;
				field.querySelectorAll('select').forEach(function (control) { control.disabled = !show; });
			});
			const isIndividual = active === 'individual';
			document.querySelector('.sms-contact-field').hidden = !isIndividual;
			document.querySelector('.sms-contact-field').classList.toggle('sms-field-wide', !isIndividual);
			if (!isIndividual) {
				phone.value = '';
				contactHint.textContent = active === 'all_active' ? '<?php echo count($seniors); ?> active senior(s) have a contact number.' : 'Recipients must have a contact number in their profile.';
			} else {
				updatePhone();
			}
		}
		function updatePhone() {
			const option = document.querySelector('.sms-individual-result[data-senior-id="' + seniorSelect.value + '"]');
			phone.value = option ? option.dataset.phone : '';
			const summary = document.getElementById('smsIndividualSummary');
			summary.textContent = option ? option.dataset.name + ' (' + option.dataset.cardId + ')' : 'Choose a senior from the search results.';
		}
		function searchIndividual() {
			const term = document.getElementById('smsSeniorSearch').value.trim().toLowerCase();
			const results = document.getElementById('smsSeniorResults');
			const rows = Array.from(results.querySelectorAll('.sms-individual-result'));
			results.querySelector('.sms-search-placeholder').hidden = term !== '';
			let matches = 0;
			rows.forEach(function (row) {
				const show = term !== '' && row.dataset.search.includes(term);
				row.hidden = !show;
				if (show) matches++;
			});
			results.querySelector('.sms-no-search-results').hidden = term === '' || matches > 0;
			results.hidden = false;
		}
		function searchSelected() {
			const term = document.getElementById('smsSelectedSearch').value.trim().toLowerCase();
			const results = document.getElementById('smsSelectedResults');
			const rows = Array.from(results.querySelectorAll('.sms-select-result'));
			results.querySelector('.sms-search-placeholder').hidden = term !== '';
			let matches = 0;
			rows.forEach(function (row) {
				const show = term !== '' && row.dataset.search.includes(term);
				row.hidden = !show;
				if (show) matches++;
			});
			results.querySelector('.sms-no-search-results').hidden = term === '' || matches > 0;
			results.hidden = false;
		}
		function updateSelectedSummary() {
			const chosen = Array.from(document.querySelectorAll('#smsSelectedResults input[type="checkbox"]:checked'));
			document.getElementById('smsSelectedSummary').textContent = chosen.length ? chosen.length + ' senior(s) selected.' : 'No seniors selected.';
		}
		function updateCount() {
			count.textContent = Array.from(message.value).length;
		}
		function recipientPreview() {
			const active = selectedAudience();
			let recipients = '';
			let contact = '';
			if (active === 'individual') {
				const option = document.querySelector('.sms-individual-result[data-senior-id="' + seniorSelect.value + '"]');
				recipients = option ? option.dataset.name + ' (' + option.dataset.cardId + ')' : 'No senior selected';
				contact = option ? (option.dataset.phone || 'No contact number') : '—';
			} else if (active === 'barangay') {
				const barangay = document.getElementById('smsCategoryBarangay').value;
				const sex = document.getElementById('smsCategorySex').value;
				const ageMin = document.getElementById('smsAgeMin').value;
				const ageMax = document.getElementById('smsAgeMax').value;
				const filters = [];
				if (barangay) filters.push(barangay);
				if (sex) filters.push(sex.charAt(0).toUpperCase() + sex.slice(1));
				if (ageMin || ageMax) filters.push((ageMin || '60') + '–' + (ageMax || '130') + ' years');
				recipients = filters.length ? filters.join(' · ') : 'No category filters selected';
				const rows = Array.from(document.querySelectorAll('#smsSelectedResults input[type="checkbox"]'));
				const matches = rows.filter(function (row) {
					const group = row.closest('.sms-select-result');
					return (!barangay || row.dataset.barangay === barangay) && (!sex || row.dataset.sex === sex) && (!ageMin || Number(row.dataset.age) >= Number(ageMin)) && (!ageMax || Number(row.dataset.age) <= Number(ageMax));
				});
				contact = matches.length + ' matching active senior(s)';
			} else if (active === 'selected') {
				const chosen = Array.from(document.querySelectorAll('#smsSelectedResults input[type="checkbox"]:checked')).map(function (input) { return input.dataset.name + ' (' + input.dataset.cardId + ')'; });
				recipients = chosen.length ? chosen.join(', ') : 'No seniors selected';
				contact = chosen.length + ' selected recipient(s)';
			} else {
				recipients = 'All Seniors';
				contact = '<?php echo count($seniors); ?> eligible recipient(s)';
			}
			return { type: labels[active], recipients: recipients, contact: contact };
		}
		audienceRadios.forEach(function (radio) { radio.addEventListener('change', updateAudience); });
		seniorSelect.addEventListener('change', updatePhone);
		document.getElementById('smsSeniorSearchButton').addEventListener('click', searchIndividual);
		document.getElementById('smsSeniorSearch').addEventListener('keydown', function (event) { if (event.key === 'Enter') { event.preventDefault(); searchIndividual(); } });
		document.getElementById('smsSelectedSearchButton').addEventListener('click', searchSelected);
		document.getElementById('smsSelectedSearch').addEventListener('keydown', function (event) { if (event.key === 'Enter') { event.preventDefault(); searchSelected(); } });
		document.getElementById('smsSeniorResults').addEventListener('click', function (event) {
			const result = event.target.closest('.sms-individual-result');
			if (!result) return;
			seniorSelect.value = result.dataset.seniorId;
			updatePhone();
		});
		document.getElementById('smsSelectedResults').addEventListener('change', updateSelectedSummary);
		message.addEventListener('input', updateCount);
		form.addEventListener('reset', function () { window.setTimeout(function () { updateCount(); updateAudience(); }, 0); });
		form.addEventListener('submit', function (event) {
			if (intent.value === 'send') return;
			event.preventDefault();
			if (!form.reportValidity()) return;
			const recipient = recipientPreview();
			const active = selectedAudience();
			const ageMin = document.getElementById('smsAgeMin').value;
			const ageMax = document.getElementById('smsAgeMax').value;
			const hasCategory = document.getElementById('smsCategoryBarangay').value || document.getElementById('smsCategorySex').value || ageMin || ageMax;
			if ((active === 'individual' && !seniorSelect.value) || (active === 'barangay' && !hasCategory) || (active === 'selected' && !document.querySelector('#smsSelectedResults input[type="checkbox"]:checked')) || (active === 'barangay' && ((ageMin && !ageMax) || (!ageMin && ageMax) || (ageMin && ageMax && Number(ageMin) > Number(ageMax))))) {
				window.alert(active === 'barangay' && !hasCategory ? 'Choose at least one category filter.' : 'Select a valid recipient or recipient group first.');
				return;
			}
			document.getElementById('previewRecipientType').textContent = recipient.type;
			document.getElementById('previewRecipientNames').textContent = recipient.recipients;
			document.getElementById('previewContact').textContent = recipient.contact;
			document.getElementById('previewMessageText').textContent = message.value;
			modal.hidden = false;
			document.getElementById('smsConfirmSend').focus();
		});
		document.getElementById('smsConfirmSend').addEventListener('click', function () {
			intent.value = 'send';
			form.requestSubmit();
		});
		document.querySelectorAll('[data-close-preview]').forEach(function (button) { button.addEventListener('click', function () { modal.hidden = true; }); });
		modal.addEventListener('click', function (event) { if (event.target === modal) modal.hidden = true; });
		const resultModal = document.getElementById('smsResultModal');
		if (resultModal) {
			resultModal.querySelector('[data-close-result]').addEventListener('click', function () { resultModal.remove(); });
			resultModal.addEventListener('click', function (event) { if (event.target === resultModal) resultModal.remove(); });
		}
		updateCount();
		updateAudience();
		updatePhone();
		updateSelectedSummary();
	})();
	</script>
</body>
</html>
