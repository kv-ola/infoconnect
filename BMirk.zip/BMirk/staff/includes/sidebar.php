<?php
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
$staffSeniorPages = ['seniors_accounts.php', 'seniors_accounts_edit.php', 'seniors_accounts_add.php'];
$staffEventPages = ['events_history.php'];
$eventsPage = in_array($currentPage, $staffEventPages, true);
$eventHistoryView = $eventsPage && ($_GET['view'] ?? '') === 'history';
$staffPostPages = ['posts_list.php', 'posts_create.php', 'posts_archive.php', 'announcements.php', 'posts_history.php'];
$staffMonitoringPages = ['activity_logs.php', 'reports.php'];
$staffSmsPages = ['sms.php'];
$staffSettingsPages = ['settings.php', 'change-password.php'];
$seniorsActive = in_array($currentPage, $staffSeniorPages, true);
$postsOpen = $eventsPage || in_array($currentPage, $staffPostPages, true);
$postsCreateActive = in_array($currentPage, ['posts_list.php', 'posts_create.php'], true);
$announcementsActive = $currentPage === 'announcements.php';
$postsArchiveActive = $currentPage === 'posts_archive.php';
$eventsActive = $eventsPage && !$eventHistoryView;
$eventHistoryActive = $currentPage === 'posts_history.php';
$monitoringOpen = in_array($currentPage, $staffMonitoringPages, true);
$smsOpen = in_array($currentPage, $staffSmsPages, true);
$settingsActive = in_array($currentPage, $staffSettingsPages, true);
?>
<link rel="stylesheet" href="/BMirk/staff/includes/assets/sidebar.css?v=19">
<link rel="stylesheet" href="/BMirk/staff/includes/assets/theme.css?v=8">

<aside class="staff-sidebar" id="shared-staff-sidebar">
    <nav class="sidebar-nav" aria-label="Staff navigation">
        <div class="nav-links">
            <a href="/BMirk/staff/home.php" class="sidebar-link<?php echo $currentPage === 'home.php' ? ' active' : ''; ?>"<?php echo $currentPage === 'home.php' ? ' aria-current="page"' : ''; ?>><svg class="sidebar-icon" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="m2.5 10.8 9.5-8 9.5 8"/><path d="M4.5 9.7V21h15V9.7M9 21v-6.5h6V21"/><path d="M7.5 11.5h1m7 0h1"/></svg><span>Home</span></a>
            <a href="/BMirk/staff/dashboard.php" class="sidebar-link<?php echo $currentPage === 'dashboard.php' ? ' active' : ''; ?>"<?php echo $currentPage === 'dashboard.php' ? ' aria-current="page"' : ''; ?>><svg class="sidebar-icon" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 20.5h18"/><path d="M5 18V11h3v7m4 0V4h3v14m4 0v-9h3v9"/><path d="M6.5 8.5h.1m7.9-7h.1m5.9 5h.1"/><path d="M4 21V9.5M11 21V2.5M18 21V7.5"/></svg><span>Dashboard</span></a>
            <a href="/BMirk/staff/seniors/accounts/seniors_accounts.php" class="sidebar-link<?php echo $seniorsActive ? ' active' : ''; ?>"<?php echo $seniorsActive ? ' aria-current="page"' : ''; ?>><svg class="sidebar-icon" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><circle cx="8.5" cy="7.5" r="3"/><path d="M2.5 20c.2-3.8 2.2-6 6-6s5.8 2.2 6 6z"/><path d="M16 5.5a2.7 2.7 0 0 1 0 5.2m1.2 3.1c2.7.4 4.1 2.2 4.3 5.2h-5"/><path d="M6.5 17h4"/></svg><span>Seniors</span></a>
        </div>

        <div class="nav-group<?php echo $postsOpen ? ' open' : ''; ?>">
            <button class="nav-button" type="button" aria-expanded="<?php echo $postsOpen ? 'true' : 'false'; ?>"><svg class="sidebar-icon" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3.5h10l3 3V21H4V3.5z"/><path d="M16.5 3.5v4h3.5M8 11h8m-8 3.5h8m-8 3.5h4"/><path d="m7.2 7.5 1 1 1.8-2"/></svg><span>Posts</span></button>
            <div class="submenu">
                <div class="submenu-inner">
                    <a href="/BMirk/staff/posts/posts_list.php" class="<?php echo $postsCreateActive ? 'active' : ''; ?>"<?php echo $postsCreateActive ? ' aria-current="page"' : ''; ?>>Create</a>
                    <a href="/BMirk/staff/posts/events_history.php" class="<?php echo $eventsActive ? 'active' : ''; ?>"<?php echo $eventsActive ? ' aria-current="page"' : ''; ?>>Events</a>
                    <a href="/BMirk/staff/posts/announcements.php" class="<?php echo $announcementsActive ? 'active' : ''; ?>"<?php echo $announcementsActive ? ' aria-current="page"' : ''; ?>>Announcements</a>
                    <a href="/BMirk/staff/posts/posts_archive.php" class="<?php echo $postsArchiveActive ? 'active' : ''; ?>"<?php echo $postsArchiveActive ? ' aria-current="page"' : ''; ?>>Archive</a>
                    <a href="/BMirk/staff/posts/posts_history.php" class="<?php echo $eventHistoryActive ? 'active' : ''; ?>"<?php echo $eventHistoryActive ? ' aria-current="page"' : ''; ?>>History</a>
                </div>
            </div>
        </div>

        <div class="nav-group<?php echo $smsOpen ? ' open' : ''; ?>">
            <button class="nav-button" type="button" aria-expanded="<?php echo $smsOpen ? 'true' : 'false'; ?>"><svg class="sidebar-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 5.5h17v12h-10l-5.5 3v-3h-1.5z"/><path d="M7 9h10m-10 4h7"/></svg><span>SMS</span></button>
            <div class="submenu">
                <div class="submenu-inner">
                    <a href="/BMirk/staff/sms/sms.php" class="<?php echo $smsOpen ? 'active' : ''; ?>"<?php echo $smsOpen ? ' aria-current="page"' : ''; ?>>Send SMS</a>
                </div>
            </div>
        </div>

        <div class="nav-group<?php echo $monitoringOpen ? ' open' : ''; ?>">
            <button class="nav-button" type="button" aria-expanded="<?php echo $monitoringOpen ? 'true' : 'false'; ?>"><svg class="sidebar-icon" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><rect x="2.5" y="3" width="19" height="14" rx="2"/><path d="M7 21h10m-5-4v4"/><path d="m5.5 13 3.2-3.2 2.7 2.1 4.6-5"/><circle cx="5.5" cy="13" r=".7"/><circle cx="8.7" cy="9.8" r=".7"/><circle cx="11.4" cy="11.9" r=".7"/><circle cx="16" cy="6.9" r=".7"/></svg><span>Monitoring</span></button>
            <div class="submenu">
                <div class="submenu-inner">
                    <a href="/BMirk/staff/monitoring/activity_logs.php" class="<?php echo $currentPage === 'activity_logs.php' ? 'active' : ''; ?>"<?php echo $currentPage === 'activity_logs.php' ? ' aria-current="page"' : ''; ?>>Activity Logs</a>
                    <a href="/BMirk/staff/monitoring/reports.php" class="<?php echo $currentPage === 'reports.php' ? 'active' : ''; ?>"<?php echo $currentPage === 'reports.php' ? ' aria-current="page"' : ''; ?>>Reports</a>
                </div>
            </div>
        </div>

        <a href="/BMirk/staff/settings/settings.php?tab=personal" class="sidebar-link<?php echo $settingsActive ? ' active' : ''; ?>"<?php echo $settingsActive ? ' aria-current="page"' : ''; ?>><svg class="sidebar-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m9.8 2.8.5-1h3.4l.5 1 1.1 1.5 1.8.2 1.2-.3 2.4 2.4-.3 1.2.2 1.8 1.5 1.1 1 .5v3.4l-1 .5-1.5 1.1-.2 1.8.3 1.2-2.4 2.4-1.2-.3-1.8.2-1.1 1.5-.5 1h-3.4l-.5-1-1.1-1.5-1.8-.2-1.2.3-2.4-2.4.3-1.2-.2-1.8-1.5-1.1-1-.5v-3.4l1-.5 1.5-1.1.2-1.8-.3-1.2 2.4-2.4 1.2.3 1.8-.2z"/><circle cx="12" cy="12" r="4"/></svg><span>Settings</span></a>
    </nav>
</aside>

<script>
(function () {
    var sidebar = document.getElementById('shared-staff-sidebar');
    if (!sidebar) return;

    sidebar.querySelectorAll('.nav-button').forEach(function (button) {
        button.addEventListener('click', function () {
            var group = button.closest('.nav-group');
            var willOpen = !group.classList.contains('open');

            sidebar.querySelectorAll('.nav-group').forEach(function (item) {
                item.classList.remove('open');
                var itemButton = item.querySelector(':scope > .nav-button');
                if (itemButton) itemButton.setAttribute('aria-expanded', 'false');
            });

            if (willOpen) {
                group.classList.add('open');
                button.setAttribute('aria-expanded', 'true');
            }
        });
    });
}());
</script>
