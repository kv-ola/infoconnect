<?php
$errors = [];
$importSummary = null;
$rowResults = [];
$issuedAccounts = [];
$csvColumns = [
	'senior_citizen_id',
	'first_name',
	'middle_name',
	'last_name',
	'suffix',
	'sex',
	'birth_date',
	'civil_status',
	'place_of_birth',
	'address',
	'barangay',
	'contact_number',
	'residence_since',
	'educational_attainment',
	'former_occupation',
	'company_name',
	'position',
	'pension_type',
	'is_pwd',
	'is_bedridden',
	'remarks',
	'birth_certificate_submitted',
	'valid_id_submitted',
];
$requiredColumns = ['senior_citizen_id', 'first_name', 'last_name', 'sex', 'birth_date', 'civil_status', 'address', 'barangay'];
$optionalColumns = array_values(array_diff($csvColumns, $requiredColumns));

if (empty($_SESSION['staff_senior_import_token'])) {
	$_SESSION['staff_senior_import_token'] = bin2hex(random_bytes(32));
}

if (($_GET['template'] ?? '') === '1') {
	header('Content-Type: text/csv; charset=utf-8');
	header('Content-Disposition: attachment; filename="senior_import_template.csv"');
	$output = fopen('php://output', 'w');
	fputcsv($output, $csvColumns);
	fclose($output);
	exit;
}

function escapeStaffSeniorImport($value): string
{
	return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function staffSeniorImportFlag(string $value): ?int
{
	$value = strtolower(trim($value));
	if ($value === '') return 0;
	if (in_array($value, ['1', 'yes', 'true', 'y'], true)) return 1;
	if (in_array($value, ['0', 'no', 'false', 'n'], true)) return 0;
	return null;
}

function staffSeniorImportRowError(array $row): ?string
{
	$lengthLimits = [
		'senior_citizen_id' => 50,
		'first_name' => 100,
		'middle_name' => 100,
		'last_name' => 100,
		'suffix' => 20,
		'place_of_birth' => 255,
		'barangay' => 150,
		'contact_number' => 30,
		'company_name' => 150,
		'position' => 150,
		'remarks' => 5000,
	];
	foreach ($lengthLimits as $field => $maxLength) {
		if (mb_strlen($row[$field], 'UTF-8') > $maxLength) {
			return ucfirst(str_replace('_', ' ', $field)) . ' exceeds ' . $maxLength . ' characters.';
		}
	}
	if ($row['contact_number'] !== '' && !preg_match('/^\d{11}$/', $row['contact_number'])) {
		return 'Contact number must contain exactly 11 digits.';
	}

	foreach (['senior_citizen_id', 'first_name', 'last_name', 'sex', 'birth_date', 'civil_status', 'address', 'barangay'] as $field) {
		if ($row[$field] === '') {
			return ucfirst(str_replace('_', ' ', $field)) . ' is required.';
		}
	}

	if (!in_array(strtolower($row['sex']), ['male', 'female'], true)) {
		return 'Sex must be male or female.';
	}

	$birthDate = DateTime::createFromFormat('!Y-m-d', $row['birth_date']);
	if (!$birthDate || $birthDate->format('Y-m-d') !== $row['birth_date'] || $row['birth_date'] > date('Y-m-d')) {
		return 'Birth date must use YYYY-MM-DD and cannot be in the future.';
	}

	$today = new DateTimeImmutable('today');
	$age = (int) $birthDate->diff($today)->format('%y');
	if ($age < 60) {
		return 'Senior applicants must be at least 60 years old.';
	}

	if ($row['residence_since'] !== '' && (!preg_match('/^\d{4}$/', $row['residence_since']) || (int) $row['residence_since'] < 1901 || (int) $row['residence_since'] > (int) date('Y'))) {
		return 'Residence since must be a valid year.';
	}
	foreach (['is_pwd', 'is_bedridden', 'birth_certificate_submitted', 'valid_id_submitted'] as $flagField) {
		if (staffSeniorImportFlag($row[$flagField]) === null) {
			return ucfirst(str_replace('_', ' ', $flagField)) . ' must be yes/no or 1/0.';
		}
	}

	return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$submittedToken = $_POST['csrf_token'] ?? '';
	if (!is_string($submittedToken) || !hash_equals($_SESSION['staff_senior_import_token'], $submittedToken)) {
		$errors[] = 'This form has expired. Refresh the page and try again.';
	} elseif (!isset($_FILES['senior_csv']) || !is_array($_FILES['senior_csv'])) {
		$errors[] = 'Select a CSV file to import.';
	} elseif ($_FILES['senior_csv']['error'] !== UPLOAD_ERR_OK) {
		$errors[] = 'The file upload failed. Select a CSV file smaller than 5 MB and try again.';
	} elseif ($_FILES['senior_csv']['size'] > 5 * 1024 * 1024) {
		$errors[] = 'The CSV file must be 5 MB or smaller.';
	} elseif (strtolower(pathinfo((string) $_FILES['senior_csv']['name'], PATHINFO_EXTENSION)) !== 'csv') {
		$errors[] = 'Upload a file with the .csv extension.';
	}

	if (!$errors && !is_uploaded_file($_FILES['senior_csv']['tmp_name'])) {
		$errors[] = 'The uploaded CSV file could not be verified.';
	}

	$csvRows = [];
	$headerMap = [];
	if (!$errors) {
		$handle = fopen($_FILES['senior_csv']['tmp_name'], 'r');
		if ($handle === false) {
			$errors[] = 'The CSV file could not be opened.';
		} else {
			$headers = fgetcsv($handle, 0, ',', '"', '\\');
			if (!is_array($headers) || !$headers) {
				$errors[] = 'The CSV file is empty or has no header row.';
			} else {
				foreach ($headers as $index => $header) {
					$header = trim((string) $header);
					if ($index === 0) {
						$header = preg_replace('/^\xEF\xBB\xBF/', '', $header);
					}
					$header = preg_replace('/\s*\*+\s*$/', '', $header);
					$headerMap[strtolower(trim($header))] = $index;
				}
				$missingColumns = array_values(array_filter(
					$requiredColumns,
					static fn ($column) => !array_key_exists($column, $headerMap)
				));
				if ($missingColumns) {
					$errors[] = 'Missing required CSV columns: ' . implode(', ', $missingColumns) . '.';
				}
			}

			if (!$errors) {
				$rowNumber = 1;
				while (($cells = fgetcsv($handle, 0, ',', '"', '\\')) !== false) {
					$rowNumber++;
					if ($cells === [null] || (count($cells) === 1 && trim((string) $cells[0]) === '')) {
						continue;
					}
					if (count($csvRows) >= 500) {
						$errors[] = 'The CSV can contain no more than 500 data rows per import.';
						break;
					}
					$row = array_fill_keys($csvColumns, '');
					foreach ($csvColumns as $column) {
						if (isset($headerMap[$column])) {
							$row[$column] = trim((string) ($cells[$headerMap[$column]] ?? ''));
						}
					}
					$row['_row_number'] = $rowNumber;
					$csvRows[] = $row;
				}
			}
			fclose($handle);
		}
	}

	if (!$errors && !$csvRows) {
		$errors[] = 'The CSV has no data rows to import.';
	}

	if (!$errors) {
		$civilStatuses = [];
		$activeBarangays = [];
		$civilStatusResult = $databaseConnection->query('SELECT id, name FROM civil_statuses WHERE is_active = 1');
		if (!$civilStatusResult) {
			$errors[] = 'Civil status records could not be loaded for the import.';
		} else {
			while ($civilStatus = $civilStatusResult->fetch_assoc()) {
				$civilStatuses[strtolower(trim($civilStatus['name']))] = (int) $civilStatus['id'];
			}
		}
		$lookupOptions = [
			'educational_attainment' => [],
			'former_occupation' => [],
			'pension_type' => [],
		];
		$lookupTables = [
			'educational_attainment' => 'educational_attainments',
			'former_occupation' => 'occupations',
			'pension_type' => 'pension_types',
		];
		foreach ($lookupTables as $column => $table) {
			try {
				$lookupResult = $databaseConnection->query("SELECT id, name FROM {$table} WHERE is_active = 1");
				while ($lookup = $lookupResult->fetch_assoc()) {
					$lookupOptions[$column][strtolower(trim($lookup['name']))] = (int) $lookup['id'];
				}
			} catch (Throwable $exception) {
				error_log('Unable to load ' . $column . ' options for senior import: ' . $exception->getMessage());
				$errors[] = 'Senior profile options could not be loaded for the import.';
				break;
			}
		}
		$barangayResult = null;
		try {
			$barangayResult = $databaseConnection->query('SELECT name FROM barangays WHERE is_active = 1');
		} catch (Throwable $exception) {
			// Keep imports usable with older databases that lack the lookup table.
			error_log('Unable to load the barangays lookup table for senior import: ' . $exception->getMessage());
			$barangayResult = $databaseConnection->query(
				"SELECT DISTINCT barangay AS name
				 FROM senior_profiles
				 WHERE barangay IS NOT NULL AND TRIM(barangay) <> ''"
			);
		}
		if (!$barangayResult) {
			$errors[] = 'Barangay records could not be loaded for the import.';
		} else {
			while ($barangay = $barangayResult->fetch_assoc()) {
				$activeBarangays[strtolower(trim($barangay['name']))] = true;
			}
		}
	}

	if (!$errors) {
		$transactionStarted = false;
		try {
			$databaseConnection->begin_transaction();
			$transactionStarted = true;

			$fileName = substr(basename((string) $_FILES['senior_csv']['name']), 0, 255);
			$totalRecords = count($csvRows);
			$batchStatement = $databaseConnection->prepare(
				"INSERT INTO import_batches (imported_by, file_name, total_records, status)
				 VALUES (?, ?, ?, 'reviewing')"
			);
			if (!$batchStatement) {
				throw new RuntimeException('Unable to start the import batch.');
			}
			$batchStatement->bind_param('isi', $staffId, $fileName, $totalRecords);
			$batchStatement->execute();
			$batchId = (int) $databaseConnection->insert_id;
			$batchStatement->close();

			$duplicateStatement = $databaseConnection->prepare('SELECT id FROM senior_profiles WHERE senior_citizen_id = ? LIMIT 1');
			$seniorInsert = $databaseConnection->prepare(
				"INSERT INTO senior_profiles
				 (senior_citizen_id, last_name, first_name, middle_name, suffix, sex, birth_date, civil_status_id,
				  place_of_birth, address, barangay, contact_number, residence_since, educational_attainment_id,
				  former_occupation_id, company_name, position, pension_type_id, is_pwd, is_bedridden, remarks,
				  status, approval_status, submitted_by)
				 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'approved', ?)"
			);
			$recordInsert = $databaseConnection->prepare(
				'INSERT INTO import_records (import_batch_id, row_number, senior_citizen_id, status, error_message, senior_id)
				 VALUES (?, ?, ?, ?, ?, ?)'
			);
			if (!$duplicateStatement || !$seniorInsert || !$recordInsert) {
				throw new RuntimeException('Unable to prepare the import operations.');
			}

			$counts = ['imported' => 0, 'duplicate' => 0, 'failed' => 0];
			$requesterId = $staffId;
			foreach ($csvRows as $row) {
				$rowNumber = (int) $row['_row_number'];
				$recordId = $row['senior_citizen_id'] !== '' ? $row['senior_citizen_id'] : null;
				$logRecordId = $recordId !== null ? substr($recordId, 0, 50) : null;
				$seniorDatabaseId = null;
				$errorMessage = staffSeniorImportRowError($row);
				$civilStatusId = $civilStatuses[strtolower(trim($row['civil_status']))] ?? null;
				if ($errorMessage === null && $civilStatusId === null) {
					$errorMessage = 'Civil status does not match an active civil status option.';
				}
				$educationKey = strtolower(trim($row['educational_attainment']));
				$occupationKey = strtolower(trim($row['former_occupation']));
				$pensionKey = strtolower(trim($row['pension_type']));
				$educationalAttainmentId = $educationKey === '' ? null : ($lookupOptions['educational_attainment'][$educationKey] ?? null);
				$formerOccupationId = $occupationKey === '' ? null : ($lookupOptions['former_occupation'][$occupationKey] ?? null);
				$pensionTypeId = $pensionKey === '' ? null : ($lookupOptions['pension_type'][$pensionKey] ?? null);
				if ($errorMessage === null && $educationKey !== '' && $educationalAttainmentId === null) $errorMessage = 'Educational attainment does not match an active option.';
				if ($errorMessage === null && $occupationKey !== '' && $formerOccupationId === null) $errorMessage = 'Former occupation does not match an active option.';
				if ($errorMessage === null && $pensionKey !== '' && $pensionTypeId === null) $errorMessage = 'Pension type does not match an active option.';
				if ($errorMessage === null && $activeBarangays && !isset($activeBarangays[strtolower(trim($row['barangay']))])) {
					$errorMessage = 'Barangay does not match an active barangay option.';
				}

				$status = 'imported';
				if ($errorMessage !== null) {
					$status = 'failed';
					$counts['failed']++;
				} else {
					$duplicateStatement->bind_param('s', $recordId);
					$duplicateStatement->execute();
					if ($duplicateStatement->get_result()->num_rows > 0) {
						$status = 'duplicate';
						$errorMessage = 'Senior Citizen ID already exists.';
						$counts['duplicate']++;
					} else {
						$databaseConnection->query('SAVEPOINT senior_import_row');
						try {
							$middleName = $row['middle_name'] !== '' ? $row['middle_name'] : null;
							$suffix = $row['suffix'] !== '' ? $row['suffix'] : null;
							$placeOfBirth = $row['place_of_birth'] !== '' ? $row['place_of_birth'] : null;
							$contactNumber = $row['contact_number'] !== '' ? $row['contact_number'] : null;
							$residenceSince = $row['residence_since'] !== '' ? $row['residence_since'] : null;
							$companyName = $row['company_name'] !== '' ? $row['company_name'] : null;
							$position = $row['position'] !== '' ? $row['position'] : null;
							$remarks = $row['remarks'] !== '' ? $row['remarks'] : null;
							$isPwd = staffSeniorImportFlag($row['is_pwd']);
							$isBedridden = staffSeniorImportFlag($row['is_bedridden']);
							$sex = strtolower($row['sex']);
							$seniorInsert->bind_param(
								'sssssssisssssiissiiisi',
								$recordId,
								$row['last_name'],
								$row['first_name'],
								$middleName,
								$suffix,
								$sex,
								$row['birth_date'],
								$civilStatusId,
								$placeOfBirth,
								$row['address'],
								$row['barangay'],
								$contactNumber,
								$residenceSince,
								$educationalAttainmentId,
								$formerOccupationId,
								$companyName,
								$position,
								$pensionTypeId,
								$isPwd,
								$isBedridden,
								$remarks,
								$requesterId
							);
							$seniorInsert->execute();
							$seniorDatabaseId = (int) $databaseConnection->insert_id;

							$account = createSeniorLoginAccount($databaseConnection, $row['senior_citizen_id']);
							$userId = (int) $account['user_id'];
							$linkAccountStatement = $databaseConnection->prepare('UPDATE senior_profiles SET user_id = ? WHERE id = ?');
							if (!$linkAccountStatement) throw new RuntimeException('Unable to link the senior login account.');
							$linkAccountStatement->bind_param('ii', $userId, $seniorDatabaseId);
							$linkAccountStatement->execute();
							$linkAccountStatement->close();

							$requirementInsert = $databaseConnection->prepare('INSERT INTO senior_requirements (senior_id, requirement_type, status) VALUES (?, ?, ?)');
							if (!$requirementInsert) throw new RuntimeException('Unable to prepare senior requirement records.');
							$requirementType = '';
							$requirementStatus = '';
							$requirementInsert->bind_param('iss', $seniorDatabaseId, $requirementType, $requirementStatus);
							foreach (['birth_certificate_submitted' => 'birth_certificate', 'valid_id_submitted' => 'valid_id'] as $column => $type) {
								$requirementType = $type;
								$requirementStatus = staffSeniorImportFlag($row[$column]) ? 'submitted' : 'missing';
								$requirementInsert->execute();
							}
							$requirementInsert->close();

							$databaseConnection->query('RELEASE SAVEPOINT senior_import_row');
							$issuedAccounts[] = [
								'name' => trim($row['first_name'] . ' ' . $row['last_name']),
								'account_id' => $account['account_id'],
								'temporary_password' => $account['temporary_password'],
							];
							$counts['imported']++;
						} catch (Throwable $exception) {
							$databaseConnection->query('ROLLBACK TO SAVEPOINT senior_import_row');
							$databaseConnection->query('RELEASE SAVEPOINT senior_import_row');
							error_log('Staff senior CSV row import failed: ' . $exception->getMessage());
							$status = 'failed';
							$errorMessage = 'The record could not be saved.';
							$seniorDatabaseId = null;
							$counts['failed']++;
						}
					}
				}

				$recordInsert->bind_param('iisssi', $batchId, $rowNumber, $logRecordId, $status, $errorMessage, $seniorDatabaseId);
				$recordInsert->execute();
				$rowResults[] = [
					'row' => $rowNumber,
					'id' => $recordId ?: 'Missing ID',
					'status' => ucfirst($status),
					'message' => $errorMessage ?? 'Record added successfully.'
				];
			}

			$duplicateStatement->close();
			$seniorInsert->close();
			$recordInsert->close();

			$batchUpdate = $databaseConnection->prepare(
				"UPDATE import_batches
				 SET total_records = ?, successful_records = ?, failed_records = ?, duplicate_records = ?,
				     status = 'completed', completed_at = NOW()
				 WHERE id = ?"
			);
			if (!$batchUpdate) {
				throw new RuntimeException('Unable to finish the import batch.');
			}
			$batchUpdate->bind_param('iiiii', $totalRecords, $counts['imported'], $counts['failed'], $counts['duplicate'], $batchId);
			$batchUpdate->execute();
			$batchUpdate->close();

			writeActivityLog(
				$databaseConnection,
				$staffId,
				'import',
				'Seniors',
				'Imported senior records from ' . $fileName . ': ' . $counts['imported'] . ' added, ' . $counts['duplicate'] . ' duplicates, ' . $counts['failed'] . ' failed.',
				$batchId
			);
			$databaseConnection->commit();
			$transactionStarted = false;
			$importSummary = $counts;
			$_SESSION['staff_senior_import_token'] = bin2hex(random_bytes(32));
		} catch (Throwable $exception) {
			if ($transactionStarted) {
				$databaseConnection->rollback();
			}
			error_log('Staff senior CSV import failed: ' . $exception->getMessage());
			$errors[] = 'The import could not be completed. No rows from this batch were saved.';
			$rowResults = [];
		}
	}
}

if ($importSummary) {
	$_SESSION['staff_senior_import_flash'] = ['type' => 'success', 'message' => 'Import complete. ' . (int) $importSummary['imported'] . ' seniors added, ' . (int) $importSummary['duplicate'] . ' duplicates skipped, ' . (int) $importSummary['failed'] . ' failed. Created login accounts are active immediately.', 'credentials' => $issuedAccounts];
} elseif ($errors) {
	$_SESSION['staff_senior_import_flash'] = ['type' => 'error', 'message' => implode(' ', $errors)];
}
header('Location: /BMirk/staff/seniors/accounts/seniors_accounts_add.php#import-results');
exit;
