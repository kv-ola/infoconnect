<?php
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/session.php';
requireLogin();

if (($_SESSION['role'] ?? '') !== 'staff') {
	header('Location: /BMirk/auth/login.php');
	exit;
}

$page_title = 'Senior Management';
$staffId = (int) ($_SESSION['user_id'] ?? 0);
$staffFirstName = $_SESSION['account_id'] ?? 'Staff';
$staffProfileStatement = $databaseConnection->prepare('SELECT first_name FROM staff_profiles WHERE user_id = ? LIMIT 1');
if ($staffProfileStatement) {
	$staffProfileStatement->bind_param('i', $staffId);
	$staffProfileStatement->execute();
	$staffProfile = $staffProfileStatement->get_result()->fetch_assoc();
	if (!empty($staffProfile['first_name'])) {
		$staffFirstName = $staffProfile['first_name'];
	}
}

$seniorAccounts = [];
$query = $databaseConnection->query(
	"SELECT sp.id, sp.senior_citizen_id, sp.first_name, sp.middle_name, sp.last_name, sp.suffix, sp.sex, sp.birth_date, sp.barangay, sp.address, sp.status, sp.created_at,
	        CASE WHEN sp.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 ELSE 0 END AS is_new,
	        u.account_id, u.status AS account_status,
	        (SELECT COUNT(DISTINCT sr.requirement_type)
	         FROM senior_requirements sr
	         WHERE sr.senior_id = sp.id
	           AND sr.requirement_type IN ('birth_certificate', 'valid_id')
	           AND sr.status <> 'missing') AS completed_requirements
	 FROM senior_profiles sp
	 LEFT JOIN users u ON u.id = sp.user_id AND u.role = 'senior'
	 ORDER BY sp.last_name, sp.first_name"
);

if ($query) {
	while ($row = $query->fetch_assoc()) {
		$rawStatus = (int) $row['completed_requirements'] < 2 ? 'pending' : strtolower($row['status'] ?? 'N/A');
		$nameParts = [
			$row['first_name'] ?? '',
			$row['middle_name'] ?? '',
			$row['last_name'] ?? '',
			$row['suffix'] ?? ''
		];
		$fullName = trim(implode(' ', array_filter($nameParts, static fn ($part) => $part !== '')));
		$age = null;
		if (!empty($row['birth_date']) && $row['birth_date'] !== '0000-00-00') {
			try {
				$age = (int) date_diff(new DateTime($row['birth_date']), new DateTime('today'))->format('%y');
			} catch (Exception $exception) {
				$age = null;
			}
		}

		$seniorAccounts[] = [
			'database_id' => (int) $row['id'],
			'id' => $row['senior_citizen_id'] ?? '',
			'name' => $fullName ?: 'Unnamed senior',
			'sex' => ucfirst($row['sex'] ?? 'N/A'),
			'age' => $age,
			'barangay' => $row['barangay'] ?: 'N/A',
			'address' => $row['address'] ?? '',
			'status' => ucfirst($rawStatus),
			'raw_status' => $rawStatus,
			'account_id' => $row['account_id'] ?: 'N/A',
			'account_status' => $row['account_status'] ? ucfirst($row['account_status']) : 'Inactive',
			'raw_account_status' => $row['account_status'] ?: 'inactive',
			'date_added' => $row['created_at'],
			'is_new' => (int) $row['is_new'] === 1
		];
	}
}

$barangays = array_values(array_unique(array_column($seniorAccounts, 'barangay')));
sort($barangays, SORT_NATURAL | SORT_FLAG_CASE);
$seniorSummary = [
	'total' => count($seniorAccounts),
	'with_account' => 0,
	'pending' => 0,
	'inactive' => 0,
];
foreach ($seniorAccounts as $seniorAccount) {
	if ($seniorAccount['account_id'] !== 'N/A') {
		$seniorSummary['with_account']++;
	}
	if ($seniorAccount['raw_status'] === 'pending') {
		$seniorSummary['pending']++;
	}
	if (in_array($seniorAccount['raw_status'], ['deceased', 'inactive'], true)) {
		$seniorSummary['inactive']++;
	}
}
$flashMessage = $_SESSION['staff_senior_flash'] ?? '';
unset($_SESSION['staff_senior_flash']);
$flashCredentials = is_array($flashMessage) ? ($flashMessage['credentials'] ?? null) : null;
$flashText = is_array($flashMessage) ? (string) ($flashMessage['message'] ?? '') : (string) $flashMessage;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo htmlspecialchars($page_title, ENT_QUOTES, 'UTF-8'); ?></title>
	<link rel="stylesheet" href="../../home.css">

	<link rel="stylesheet" href="../../assets/table.css?v=17">
	<link rel="stylesheet" href="assets/seniors_accounts.css?v=7">
</head>
<body>
	<div class="staff-layout">
		<?php include __DIR__ . '/../../includes/sidebar.php'; ?>

		<main class="staff-main">
			<?php include __DIR__ . '/../../includes/header.php'; ?>

			<section class="staff-content seniors-page staff-seniors-page">
				<header class="seniors-heading">
					<div>
						<h1>Senior Management</h1>
						<p>View, search, and manage senior citizen records.</p>
					</div>
					<div class="senior-account-actions">
						<a class="senior-account-action senior-account-action-primary" href="/BMirk/staff/seniors/accounts/seniors_accounts_add.php">
							<span aria-hidden="true">+</span> Add Senior
						</a>
					</div>
				</header>

				<?php if ($flashText !== ''): ?>
					<div class="form-success" role="status"><?php echo htmlspecialchars($flashText, ENT_QUOTES, 'UTF-8'); ?></div>
				<?php endif; ?>
				<?php if (is_array($flashCredentials)): ?>
					<div class="form-success" role="status">
						<strong>New senior login credentials — share these securely:</strong><br>
						Username: <code><?php echo htmlspecialchars((string) $flashCredentials['account_id'], ENT_QUOTES, 'UTF-8'); ?></code><br>
						Temporary password: <code><?php echo htmlspecialchars((string) $flashCredentials['temporary_password'], ENT_QUOTES, 'UTF-8'); ?></code><br>
						The senior must change this password at first login. The account is active immediately.
					</div>
				<?php endif; ?>

				<div class="staff-senior-summary-grid" aria-label="Senior record summary">
					<article class="staff-senior-summary-card staff-summary-total">
						<span class="staff-senior-summary-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M2.5 20c.3-3.8 2.5-5.8 6.5-5.8s6.2 2 6.5 5.8M15 14c3.8-.2 5.8 1.7 6.2 5"/></svg></span>
						<span class="staff-senior-summary-copy"><span>Total Seniors</span><strong><?php echo number_format($seniorSummary['total']); ?></strong><small>Senior citizen records</small></span>
					</article>
					<article class="staff-senior-summary-card staff-summary-accounts">
						<span class="staff-senior-summary-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2z"/></svg></span>
						<span class="staff-senior-summary-copy"><span>Seniors with Account</span><strong><?php echo number_format($seniorSummary['with_account']); ?></strong><small><?php echo $seniorSummary['total'] > 0 ? number_format(($seniorSummary['with_account'] / $seniorSummary['total']) * 100, 1) : '0.0'; ?>% of seniors</small></span>
					</article>
					<article class="staff-senior-summary-card staff-summary-pending">
						<span class="staff-senior-summary-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M6 2.5h9l5 5v14H6z"/><path d="M14 2.5v5h6M9 12h8m-8 3.5h8m-8 3.5h5"/></svg></span>
						<span class="staff-senior-summary-copy"><span>Pending for Approval</span><strong><?php echo number_format($seniorSummary['pending']); ?></strong><small>Awaiting review</small></span>
					</article>
					<article class="staff-senior-summary-card staff-summary-inactive">
						<span class="staff-senior-summary-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3"/><path d="M2.5 20c.3-3.8 2.5-5.8 6.5-5.8s6.2 2 6.5 5.8M18 8l4 4m0-4-4 4"/></svg></span>
						<span class="staff-senior-summary-copy"><span>Deceased / Inactive</span><strong><?php echo number_format($seniorSummary['inactive']); ?></strong><small>Records needing attention</small></span>
					</article>
				</div>

				<div class="page-card seniors-table-card">
					<div class="senior-filter-toolbar">
						<div class="filter-field search-filter-field staff-search-field">
							<label class="staff-search-label" for="accountSearch">Search</label>
							<div class="search-group">
								<input id="accountSearch" type="search" placeholder="Name, senior ID, or address..." aria-label="Search senior records">
								<button id="searchButton" type="button">Search</button>
							</div>
						</div>
						<label class="filter-field">
							<span>Barangay</span>
							<select id="barangayFilter">
								<option value="All">All</option>
								<?php foreach ($barangays as $barangay): ?>
									<option value="<?php echo htmlspecialchars($barangay, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($barangay, ENT_QUOTES, 'UTF-8'); ?></option>
								<?php endforeach; ?>
							</select>
						</label>
						<label class="filter-field">
							<span>Sex</span>
							<select id="sexFilter">
								<option value="All">All</option>
								<option value="Male">Male</option>
								<option value="Female">Female</option>
							</select>
						</label>
						<label class="filter-field">
							<span>Status</span>
							<select id="statusFilter">
								<option value="All">All</option>
								<option value="active">Active</option>
								<option value="pending">Pending</option>
								<option value="unlocated">Unlocated</option>
								<option value="transferred">Transferred</option>
								<option value="unclaimed">Unclaimed</option>
								<option value="deceased">Deceased</option>
							</select>
						</label>
						<label class="filter-field senior-age-filter">
							<span>Age Range</span>
							<select id="ageRangeFilter" aria-label="Filter by age range">
								<option value="All">All</option>
								<option value="60-69">60-69</option>
								<option value="70-79">70-79</option>
								<option value="80-89">80-89</option>
								<option value="90-99">90-99</option>
								<option value="100+">100+</option>
							</select>
						</label>
						<label class="filter-field">
							<span>Added</span>
							<select id="addedFilter" aria-label="Filter by recently added seniors">
								<option value="All">All</option>
								<option value="New">New</option>
							</select>
						</label>
					</div>

					<div class="table-wrap staff-consistent-table-wrap">
						<table class="data-table staff-consistent-table senior-data-table" id="seniorAccountsTable">
							<thead>
								<tr>
									<th>#</th>
									<th>Senior ID</th>
									<th>Full Name</th>
									<th>Sex</th>
									<th>Age</th>
									<th>Barangay</th>
									<th>Status</th>
									<th>Account ID</th>
									<th>Account Status</th>
									<th>Date Added</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($seniorAccounts as $index => $account): ?>
								<tr data-index="<?php echo $index + 1; ?>" data-name="<?php echo htmlspecialchars(strtolower($account['name']), ENT_QUOTES, 'UTF-8'); ?>" data-id="<?php echo htmlspecialchars(strtolower($account['id']), ENT_QUOTES, 'UTF-8'); ?>" data-account-id="<?php echo htmlspecialchars(strtolower($account['account_id']), ENT_QUOTES, 'UTF-8'); ?>" data-address="<?php echo htmlspecialchars(strtolower($account['address']), ENT_QUOTES, 'UTF-8'); ?>" data-age="<?php echo $account['age'] === null ? '' : (int) $account['age']; ?>" data-barangay="<?php echo htmlspecialchars($account['barangay'], ENT_QUOTES, 'UTF-8'); ?>" data-sex="<?php echo htmlspecialchars($account['sex'], ENT_QUOTES, 'UTF-8'); ?>" data-status="<?php echo htmlspecialchars($account['raw_status'], ENT_QUOTES, 'UTF-8'); ?>" data-is-new="<?php echo $account['is_new'] ? '1' : '0'; ?>">
										<td class="row-number"><?php echo $index + 1; ?></td>
										<td><?php echo htmlspecialchars((string) $account['id'], ENT_QUOTES, 'UTF-8'); ?></td>
										<td><?php echo htmlspecialchars($account['name'], ENT_QUOTES, 'UTF-8'); ?></td>
										<td><?php echo htmlspecialchars($account['sex'], ENT_QUOTES, 'UTF-8'); ?></td>
										<td><?php echo $account['age'] === null ? 'N/A' : (int) $account['age']; ?></td>
										<td><?php echo htmlspecialchars($account['barangay'], ENT_QUOTES, 'UTF-8'); ?></td>
										<td><span class="status-badge <?php echo htmlspecialchars(strtolower($account['status']), ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($account['status'], ENT_QUOTES, 'UTF-8'); ?></span></td>
										<td><?php echo htmlspecialchars($account['account_id'], ENT_QUOTES, 'UTF-8'); ?></td>
										<td><span class="status-badge <?php echo htmlspecialchars($account['raw_account_status'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($account['account_status'], ENT_QUOTES, 'UTF-8'); ?></span></td>
										<td><?php echo htmlspecialchars(date('M j, Y g:i A', strtotime($account['date_added'])), ENT_QUOTES, 'UTF-8'); ?></td>
										<td><a class="section-action" href="/BMirk/staff/seniors/accounts/seniors_accounts_edit.php?id=<?php echo $account['database_id']; ?>">Edit</a></td>
									</tr>
								<?php endforeach; ?>
								<tr id="emptyState" hidden>
									<td colspan="11">No matching senior accounts found.</td>
								</tr>
							</tbody>
						</table>
					</div>
					<footer class="senior-table-footer staff-consistent-table-footer">
						<p class="senior-result-count staff-consistent-result-count" id="resultCount" aria-live="polite"></p>
						<div class="pagination staff-consistent-pagination" id="pagination" aria-label="Result pages"></div>
					</footer>
				</div>
			</section>
		</main>
	</div>

	<script>
		const rows = Array.from(document.querySelectorAll('#seniorAccountsTable tbody tr[data-name]'));
		const searchInput = document.getElementById('accountSearch');
		const ageRangeFilter = document.getElementById('ageRangeFilter');
		const barangayFilter = document.getElementById('barangayFilter');
		const sexFilter = document.getElementById('sexFilter');
		const statusFilter = document.getElementById('statusFilter');
		const addedFilter = document.getElementById('addedFilter');
		const searchButton = document.getElementById('searchButton');
		const pagination = document.getElementById('pagination');
		const emptyState = document.getElementById('emptyState');
		const resultCount = document.getElementById('resultCount');
		const pageSize = 10;
		let currentPage = 1;

		function applyFilters() {
			const term = searchInput.value.trim().toLocaleLowerCase();
			const selectedAgeRange = ageRangeFilter.value;
			const selectedBarangay = barangayFilter.value;
			const selectedSex = sexFilter.value;
			const selectedStatus = statusFilter.value;
			const selectedAdded = addedFilter.value;
			const filteredRows = rows.filter(function (row) {
				const age = Number(row.dataset.age);
				const ageBounds = selectedAgeRange === 'All' ? null : selectedAgeRange.split('-').map(Number);
				const matchesAge = selectedAgeRange === 'All'
					|| (row.dataset.age !== '' && (selectedAgeRange === '100+'
						? age >= 100
						: age >= ageBounds[0] && age <= ageBounds[1]));
				return (!term || row.dataset.name.includes(term) || row.dataset.id.includes(term) || row.dataset.accountId.includes(term) || row.dataset.address.includes(term))
					&& matchesAge
					&& (selectedBarangay === 'All' || row.dataset.barangay === selectedBarangay)
					&& (selectedSex === 'All' || row.dataset.sex === selectedSex)
					&& (selectedStatus === 'All' || row.dataset.status === selectedStatus)
					&& (selectedAdded !== 'New' || row.dataset.isNew === '1');
			});

			const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));
			currentPage = Math.min(currentPage, totalPages);
			const visibleRows = filteredRows.slice((currentPage - 1) * pageSize, currentPage * pageSize);
			rows.forEach(function (row) {
				row.hidden = !visibleRows.includes(row);
				if (!row.hidden) row.querySelector('.row-number').textContent = String(filteredRows.indexOf(row) + 1);
			});
			emptyState.hidden = filteredRows.length !== 0;
			resultCount.textContent = filteredRows.length
				? 'Showing ' + ((currentPage - 1) * pageSize + 1) + ' to ' + ((currentPage - 1) * pageSize + visibleRows.length) + ' of ' + filteredRows.length + ' records'
				: 'No records found';
			renderPagination(totalPages);
		}

		function renderPagination(totalPages) {
			const firstPage = Math.max(1, Math.min(currentPage - 2, totalPages - 4));
			const lastPage = Math.min(totalPages, firstPage + 4);
			const buttons = [];
			for (let page = firstPage; page <= lastPage; page++) {
				buttons.push('<button class="page-btn' + (page === currentPage ? ' active' : '') + '" type="button" data-page="' + page + '"' + (page === currentPage ? ' aria-current="page"' : '') + '>' + page + '</button>');
			}
			pagination.innerHTML =
				'<button class="page-arrow" type="button" data-page="' + (currentPage - 1) + '" aria-label="Previous page"' + (currentPage === 1 ? ' disabled' : '') + '>Previous</button>' +
				buttons.join('') +
				'<button class="page-arrow" type="button" data-page="' + (currentPage + 1) + '" aria-label="Next page"' + (currentPage === totalPages ? ' disabled' : '') + '>Next</button>';

			pagination.querySelectorAll('button[data-page]').forEach(function (button) {
				button.addEventListener('click', function () {
					const targetPage = Number(button.dataset.page);
					if (targetPage >= 1 && targetPage <= totalPages) {
						currentPage = targetPage;
						applyFilters();
					}
				});
			});
		}

		[barangayFilter, sexFilter, statusFilter, addedFilter].forEach(function (filter) {
			filter.addEventListener('change', function () {
				currentPage = 1;
				applyFilters();
			});
		});
		ageRangeFilter.addEventListener('change', function () {
			currentPage = 1;
			applyFilters();
		});
		searchButton.addEventListener('click', function () {
			currentPage = 1;
			applyFilters();
		});
		searchInput.addEventListener('keydown', function (event) {
			if (event.key === 'Enter') {
				event.preventDefault();
				searchButton.click();
			}
		});
		applyFilters();
	</script>
</body>
</html>
