<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/activity_log.php';
requireLogin();

if (($_SESSION['role'] ?? '') !== 'staff') {
    header('Location: /BMirk/auth/login.php');
    exit;
}

activityLogClearDatabase($databaseConnection);

$page_title = 'Activity Logs';
$pageSize = 10;
$pageError = '';
$totalEntries = 0;
$activityLogs = [];
$roleOptions = [];
$actionOptions = [];
$moduleOptions = [];

$search = trim(is_string($_GET['search'] ?? null) ? $_GET['search'] : '');
$roleFilter = trim(is_string($_GET['role'] ?? null) ? $_GET['role'] : '');
$actionFilter = trim(is_string($_GET['action'] ?? null) ? $_GET['action'] : '');
$moduleFilter = trim(is_string($_GET['module'] ?? null) ? $_GET['module'] : '');
$dateFrom = trim(is_string($_GET['date_from'] ?? null) ? $_GET['date_from'] : '');
$dateTo = trim(is_string($_GET['date_to'] ?? null) ? $_GET['date_to'] : '');
$pageNumber = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT);
$pageNumber = $pageNumber !== false && $pageNumber > 0 ? $pageNumber : 1;

function staffActivityEscape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function staffActivityValidDate(string $value): bool
{
    $date = DateTime::createFromFormat('!Y-m-d', $value);
    return $date !== false && $date->format('Y-m-d') === $value;
}

if (($dateFrom !== '' && !staffActivityValidDate($dateFrom)) || ($dateTo !== '' && !staffActivityValidDate($dateTo))) {
    $pageError = 'Enter valid start and end dates.';
} elseif ($dateFrom !== '' && $dateTo !== '' && $dateFrom > $dateTo) {
    $pageError = 'The start date must not be later than the end date.';
}

if ($pageError === '') {
    try {
        $allLogs = activityLogReadFiles();
        $roleOptionsByValue = [];
        $actionOptionsByValue = [];
        $moduleOptionsByValue = [];
        foreach ($allLogs as $log) {
            if ($log['role'] !== '') {
                $roleOptionsByValue[$log['role']] = true;
            }
            if ($log['action'] !== '') {
                $actionOptionsByValue[$log['action']] = true;
            }
            if ($log['module'] !== '') {
                $moduleOptionsByValue[$log['module']] = true;
            }

            $logDate = substr($log['created_at'], 0, 10);
            if (($roleFilter !== '' && $log['role'] !== $roleFilter)
                || ($actionFilter !== '' && $log['action'] !== $actionFilter)
                || ($moduleFilter !== '' && $log['module'] !== $moduleFilter)
                || ($dateFrom !== '' && $logDate < $dateFrom)
                || ($dateTo !== '' && $logDate > $dateTo)) {
                continue;
            }
            $searchable = implode(' ', [$log['account_id'], $log['role'], $log['action'], $log['module'], $log['description']]);
            if ($search !== '' && stripos($searchable, $search) === false) {
                continue;
            }
            $activityLogs[] = $log;
        }
        $roleOptions = array_keys($roleOptionsByValue);
        $actionOptions = array_keys($actionOptionsByValue);
        $moduleOptions = array_keys($moduleOptionsByValue);
        sort($roleOptions, SORT_NATURAL | SORT_FLAG_CASE);
        sort($actionOptions, SORT_NATURAL | SORT_FLAG_CASE);
        sort($moduleOptions, SORT_NATURAL | SORT_FLAG_CASE);
        $totalEntries = count($activityLogs);
    } catch (Throwable $exception) {
        error_log('Unable to load staff activity logs: ' . $exception->getMessage());
        $pageError = 'Activity logs could not be loaded. Please try again later.';
    }
}

$totalPages = max(1, (int) ceil($totalEntries / $pageSize));
$pageNumber = min($pageNumber, $totalPages);
$offset = ($pageNumber - 1) * $pageSize;
$activityLogs = array_slice($activityLogs, $offset, $pageSize);
$queryParameters = array_filter([
    'search' => $search,
    'role' => $roleFilter,
    'action' => $actionFilter,
    'module' => $moduleFilter,
    'date_from' => $dateFrom,
    'date_to' => $dateTo,
], static fn ($value): bool => $value !== '');
$paginationPages = array_values(array_unique(array_filter(
    [1, $pageNumber - 2, $pageNumber - 1, $pageNumber, $pageNumber + 1, $pageNumber + 2, $totalPages],
    static fn ($number): bool => $number >= 1 && $number <= $totalPages
)));
sort($paginationPages);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo staffActivityEscape($page_title); ?></title>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="/BMirk/staff/assets/table.css?v=18">
    <link rel="stylesheet" href="assets/activity_logs.css?v=1">
</head>
<body>
    <div class="staff-layout">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <main class="staff-main">
            <?php include __DIR__ . '/../includes/header.php'; ?>
            <section class="staff-content activity-logs-page staff-logs-page">
                <header class="activity-logs-heading">
                    <h1>Activity Logs</h1>
                    <p>Review and filter recorded activity across InfoConnect.</p>
                </header>
                <?php if ($pageError !== ''): ?><div class="activity-logs-error" role="alert"><?php echo staffActivityEscape($pageError); ?></div><?php endif; ?>
                <section class="home-card activity-log-card" aria-label="Activity log records">
                    <form class="activity-filter-grid" id="activityFilterForm" method="get" action="">
                        <div class="activity-search staff-search-field">
                            <label class="staff-search-label" for="activitySearch">Search</label>
                            <input id="activitySearch" name="search" type="search" value="<?php echo staffActivityEscape($search); ?>" placeholder="Search users, actions, modules, or details..." aria-label="Search activity logs">
                            <button type="submit">Search</button>
                        </div>
                        <label class="activity-filter" for="activityRole"><span>Role</span><select id="activityRole" name="role"><option value="">All Roles</option><?php foreach ($roleOptions as $option): ?><option value="<?php echo staffActivityEscape($option); ?>" <?php echo $roleFilter === $option ? 'selected' : ''; ?>><?php echo staffActivityEscape(ucfirst($option)); ?></option><?php endforeach; ?></select></label>
                        <label class="activity-filter" for="activityAction"><span>Action</span><select id="activityAction" name="action"><option value="">All Actions</option><?php foreach ($actionOptions as $option): ?><option value="<?php echo staffActivityEscape($option); ?>" <?php echo $actionFilter === $option ? 'selected' : ''; ?>><?php echo staffActivityEscape(ucfirst($option)); ?></option><?php endforeach; ?></select></label>
                        <label class="activity-filter" for="activityModule"><span>Module</span><select id="activityModule" name="module"><option value="">All Modules</option><?php foreach ($moduleOptions as $option): ?><option value="<?php echo staffActivityEscape($option); ?>" <?php echo $moduleFilter === $option ? 'selected' : ''; ?>><?php echo staffActivityEscape(ucfirst($option)); ?></option><?php endforeach; ?></select></label>
                        <label class="activity-filter" for="activityDateFrom"><span>Date From</span><input id="activityDateFrom" name="date_from" type="date" value="<?php echo staffActivityEscape($dateFrom); ?>"></label>
                        <label class="activity-filter" for="activityDateTo"><span>Date To</span><input id="activityDateTo" name="date_to" type="date" value="<?php echo staffActivityEscape($dateTo); ?>"></label>
                        <input type="hidden" name="page" value="1">
                    </form>
                    <div class="activity-table-wrap staff-consistent-table-wrap">
                        <table class="data-table staff-consistent-table activity-table">
                            <thead><tr><th scope="col">#</th><th scope="col">Date &amp; Time</th><th scope="col">User</th><th scope="col">Role</th><th scope="col">Action</th><th scope="col">Module</th><th scope="col">Details</th></tr></thead>
                            <tbody>
                                <?php if ($pageError !== ''): ?><tr><td colspan="7" class="activity-empty">Logs are unavailable.</td></tr>
                                <?php elseif (!$activityLogs): ?><tr><td colspan="7" class="activity-empty"><?php echo $search === '' && $roleFilter === '' && $actionFilter === '' && $moduleFilter === '' && $dateFrom === '' && $dateTo === '' ? 'No activity logs found.' : 'No activity logs match these filters.'; ?></td></tr>
                                <?php else: foreach ($activityLogs as $index => $log): ?>
                                    <tr><td class="activity-row-number"><?php echo $offset + $index + 1; ?></td><td><?php echo staffActivityEscape(date('M j, Y h:i:s A', strtotime($log['created_at']))); ?></td><td><?php echo staffActivityEscape($log['account_id'] ?: 'System'); ?></td><td><?php echo staffActivityEscape($log['role'] ? ucfirst($log['role']) : 'System'); ?></td><td><?php echo staffActivityEscape(ucfirst($log['action'])); ?></td><td><?php echo staffActivityEscape(ucfirst($log['module'])); ?></td><td class="activity-details"><?php echo staffActivityEscape($log['description'] ?: '—'); ?></td></tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <footer class="activity-table-footer staff-consistent-table-footer">
                        <p class="activity-result-count" aria-live="polite"><?php if ($totalEntries > 0 && $pageError === ''): ?>Showing <?php echo $offset + 1; ?> to <?php echo min($offset + count($activityLogs), $totalEntries); ?> of <?php echo number_format($totalEntries); ?> entries<?php else: ?>Showing 0 entries<?php endif; ?></p>
                        <?php if ($totalPages > 1 && $pageError === ''): ?><nav class="activity-pagination" aria-label="Activity log pages"><a class="page-control <?php echo $pageNumber <= 1 ? 'disabled' : ''; ?>" href="?<?php echo staffActivityEscape(http_build_query($queryParameters + ['page' => max(1, $pageNumber - 1)])); ?>" <?php echo $pageNumber <= 1 ? 'aria-disabled="true" tabindex="-1"' : ''; ?>>Previous</a><?php $previousPage = 0; foreach ($paginationPages as $paginationPage): ?><?php if ($paginationPage - $previousPage > 1): ?><span class="page-ellipsis" aria-hidden="true">...</span><?php endif; ?><a class="page-number <?php echo $paginationPage === $pageNumber ? 'active' : ''; ?>" href="?<?php echo staffActivityEscape(http_build_query($queryParameters + ['page' => $paginationPage])); ?>" <?php echo $paginationPage === $pageNumber ? 'aria-current="page"' : ''; ?>><?php echo $paginationPage; ?></a><?php $previousPage = $paginationPage; endforeach; ?><a class="page-control <?php echo $pageNumber >= $totalPages ? 'disabled' : ''; ?>" href="?<?php echo staffActivityEscape(http_build_query($queryParameters + ['page' => min($totalPages, $pageNumber + 1)])); ?>" <?php echo $pageNumber >= $totalPages ? 'aria-disabled="true" tabindex="-1"' : ''; ?>>Next</a></nav><?php endif; ?>
                    </footer>
                </section>
            </section>
        </main>
    </div>
    <script>
        const activityFilterForm = document.getElementById('activityFilterForm');
        if (activityFilterForm) {
            const searchInput = document.getElementById('activitySearch');
            let searchTimeout;
            if (searchInput) searchInput.addEventListener('input', function () {
                window.clearTimeout(searchTimeout);
                searchTimeout = window.setTimeout(function () { activityFilterForm.requestSubmit(); }, 300);
            });
            activityFilterForm.querySelectorAll('select, input[type="date"]').forEach(function (filter) {
                filter.addEventListener('change', function () { activityFilterForm.requestSubmit(); });
            });
        }
    </script>
</body>
</html>
