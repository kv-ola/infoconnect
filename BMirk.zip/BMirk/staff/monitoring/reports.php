<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/activity_log.php';
requireLogin();

if (($_SESSION['role'] ?? '') !== 'staff') {
    header('Location: /BMirk/auth/login.php');
    exit;
}

$page_title = 'Reports';
$pageSize = 10;
$pageError = '';
$reportTypes = [
    'senior' => ['name' => 'Senior Records', 'summary' => 'Senior Records Report'],
    'sms' => ['name' => 'SMS', 'summary' => 'SMS Report'],
];
$reportType = is_string($_GET['type'] ?? null) && isset($reportTypes[$_GET['type']]) ? $_GET['type'] : 'senior';
$month = filter_var($_GET['month'] ?? date('n'), FILTER_VALIDATE_INT);
$month = $month !== false && $month >= 0 && $month <= 12 ? $month : (int) date('n');
$year = filter_var($_GET['year'] ?? date('Y'), FILTER_VALIDATE_INT);
$currentYear = (int) date('Y');
$year = $year !== false && $year >= 2000 && $year <= $currentYear ? $year : $currentYear;
$search = trim(is_string($_GET['search'] ?? null) ? $_GET['search'] : '');
$day = filter_var($_GET['day'] ?? 0, FILTER_VALIDATE_INT);
$day = $day !== false && $day >= 0 && $day <= 31 ? $day : 0;
$barangay = trim(is_string($_GET['barangay'] ?? null) ? $_GET['barangay'] : '');
$barangayOptions = [];
if ($reportType === 'senior') {
    $barangayResult = $databaseConnection->query("SELECT DISTINCT barangay FROM senior_profiles WHERE TRIM(COALESCE(barangay, '')) <> '' ORDER BY barangay");
    while ($barangayRow = $barangayResult->fetch_assoc()) $barangayOptions[] = (string) $barangayRow['barangay'];
    if ($barangay !== '' && !in_array($barangay, $barangayOptions, true)) $barangay = '';
} else {
    $barangay = '';
}
$csvExport = ($_SERVER['REQUEST_METHOD'] ?? '') === 'GET' && ($_GET['export'] ?? '') === 'csv';
$pageNumber = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT);
$pageNumber = $pageNumber !== false && $pageNumber > 0 ? $pageNumber : 1;
$periodStart = sprintf('%04d-%02d-01 00:00:00', $year, $month === 0 ? 1 : $month);
$periodEnd = $month === 0
    ? sprintf('%04d-01-01 00:00:00', $year + 1)
    : (new DateTimeImmutable($periodStart))->modify('first day of next month')->format('Y-m-d H:i:s');
$periodLabel = $month === 0 ? 'All Months ' . $year : date('F Y', strtotime($periodStart));
$periodLabel = $day > 0 ? ($month === 0 ? 'Day ' . $day . ', All Months ' . $year : date('F', strtotime($periodStart)) . ' ' . $day . ', ' . $year) : $periodLabel;
if ($barangay !== '') $periodLabel .= ' · ' . $barangay;
$barangayColumn = $reportType === 'senior' ? 'sp.barangay' : "''";
$reportRows = [];
$reportTotal = 0;
$reportHeaders = [];
$seniorMetrics = ['total' => 0, 'male' => 0, 'female' => 0, 'active' => 0, 'pending' => 0, 'deceased' => 0];

function staffReportsEscape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$reportSpecs = [
    'senior' => [
        'date' => 'sp.created_at',
        'search' => "sp.senior_citizen_id, sp.first_name, sp.middle_name, sp.last_name, sp.barangay, sp.status",
        'from' => "FROM senior_profiles sp
            LEFT JOIN (SELECT senior_id, COUNT(DISTINCT requirement_type) AS completed_requirements
                       FROM senior_requirements
                       WHERE status <> 'missing'
                       GROUP BY senior_id) requirement_counts ON requirement_counts.senior_id = sp.id",
        'select' => "sp.senior_citizen_id AS senior_id, CONCAT_WS(' ', sp.first_name, NULLIF(sp.middle_name, ''), sp.last_name, NULLIF(sp.suffix, '')) AS full_name, sp.barangay, TIMESTAMPDIFF(YEAR, sp.birth_date, CURDATE()) AS age, sp.sex, CASE WHEN COALESCE(requirement_counts.completed_requirements, 0) < 2 THEN 'pending' ELSE sp.status END AS status, sp.created_at AS date_added",
        'order' => 'sp.created_at DESC, sp.id DESC',
        'headers' => ['#', 'Senior ID', 'Name', 'Barangay', 'Age', 'Sex', 'Status', 'Date Added'],
    ],
    'event' => [
        'date' => 'e.event_date',
        'search' => 'e.title, e.location, e.status',
        'from' => 'FROM events e',
        'select' => 'e.title AS title, e.event_date AS event_date, e.location AS venue, e.status AS status',
        'order' => 'e.event_date DESC, e.id DESC',
        'headers' => ['Event Title', 'Date', 'Venue', 'Status'],
    ],
    'announcement' => [
        'date' => 'a.created_at',
        'search' => 'a.title, a.status, a.content',
        'from' => 'FROM announcements a',
        'select' => 'a.title AS title, a.status AS status, a.published_at AS published_at, a.expires_at AS expires_at, a.created_at AS date_created',
        'order' => 'a.created_at DESC, a.id DESC',
        'headers' => ['Title', 'Status', 'Published At', 'Expires At', 'Date Created'],
    ],
    'sms' => [
        'date' => 'm.created_at',
        'search' => 'm.sms_type, m.status, m.recipient_type, m.message',
        'from' => 'FROM sms_messages m',
        'select' => 'm.sms_type AS type, m.recipient_type AS recipients, m.status AS status, m.scheduled_at AS scheduled_at, m.sent_at AS sent_at, m.created_at AS date_created',
        'order' => 'm.created_at DESC, m.id DESC',
        'headers' => ['Message Type', 'Recipient Group', 'Status', 'Scheduled', 'Sent At', 'Date Created'],
    ],
    'activity' => [
        'headers' => ['Date & Time', 'User', 'Role', 'Action', 'Module', 'Details'],
    ],
];
$spec = $reportSpecs[$reportType];
$reportHeaders = $spec['headers'];
$filterSql = $reportType === 'activity'
    ? ''
    : "WHERE {$spec['date']} >= ? AND {$spec['date']} < ?
        AND (? = '' OR CONCAT_WS(' ', {$spec['search']}) LIKE CONCAT('%', ?, '%'))
        AND (? = '' OR {$barangayColumn} = ?)
        AND (? = 0 OR DAY({$spec['date']}) = ?)";

try {
    if ($reportType === 'activity') {
        $monthStart = sprintf('%04d-%02d-01', $year, $month === 0 ? 1 : $month);
        $monthEnd = $month === 0
            ? sprintf('%04d-12-31', $year)
            : (new DateTimeImmutable($monthStart))->modify('last day of this month')->format('Y-m-d');
        $activityRows = activityLogReadFiles($monthStart, $monthEnd);
        foreach ($activityRows as $activity) {
            $searchable = implode(' ', [$activity['account_id'], $activity['role'], $activity['action'], $activity['module'], $activity['description']]);
            if ($search !== '' && stripos($searchable, $search) === false) {
                continue;
            }
            $reportRows[] = [
                'date_time' => $activity['created_at'],
                'account_id' => $activity['account_id'] ?: 'System',
                'role' => $activity['role'] ?: 'system',
                'action' => $activity['action'],
                'module' => $activity['module'],
                'details' => $activity['description'],
            ];
        }
        $reportTotal = count($reportRows);
        $totalPages = max(1, (int) ceil($reportTotal / $pageSize));
        $pageNumber = min($pageNumber, $totalPages);
        $reportRows = array_slice($reportRows, ($pageNumber - 1) * $pageSize, $pageSize);
    } elseif ($reportType === 'senior') {
        $seniorMetricsStatement = $databaseConnection->prepare(
            "SELECT COUNT(*) AS total,
                    SUM(sp.sex = 'male') AS male,
                    SUM(sp.sex = 'female') AS female,
                    SUM(COALESCE(requirement_counts.completed_requirements, 0) >= 2 AND sp.status = 'active') AS active,
                    SUM(COALESCE(requirement_counts.completed_requirements, 0) < 2 OR sp.status = 'pending') AS pending,
                    SUM(COALESCE(requirement_counts.completed_requirements, 0) >= 2 AND sp.status = 'deceased') AS deceased
             FROM senior_profiles sp
             LEFT JOIN (SELECT senior_id, COUNT(DISTINCT requirement_type) AS completed_requirements
                        FROM senior_requirements
                        WHERE status <> 'missing'
                        GROUP BY senior_id) requirement_counts ON requirement_counts.senior_id = sp.id
             WHERE sp.created_at >= ? AND sp.created_at < ?
               AND (? = '' OR sp.barangay = ?)
               AND (? = 0 OR DAY(sp.created_at) = ?)"
        );
        $seniorMetricsStatement->bind_param('ssssii', $periodStart, $periodEnd, $barangay, $barangay, $day, $day);
        $seniorMetricsStatement->execute();
        $seniorMetrics = array_map('intval', $seniorMetricsStatement->get_result()->fetch_assoc());
        $seniorMetricsStatement->close();
    }

    if ($reportType !== 'activity') {
        $countStatement = $databaseConnection->prepare("SELECT COUNT(*) AS total {$spec['from']} {$filterSql}");
        $countStatement->bind_param('ssssssii', $periodStart, $periodEnd, $search, $search, $barangay, $barangay, $day, $day);
        $countStatement->execute();
        $reportTotal = (int) $countStatement->get_result()->fetch_assoc()['total'];
        $countStatement->close();

        $totalPages = max(1, (int) ceil($reportTotal / $pageSize));
        $pageNumber = min($pageNumber, $totalPages);
        $offset = ($pageNumber - 1) * $pageSize;
        $dataStatement = $databaseConnection->prepare(
            "SELECT {$spec['select']} {$spec['from']} {$filterSql}
             ORDER BY {$spec['order']}
             " . ($csvExport ? '' : "LIMIT {$pageSize} OFFSET {$offset}")
        );
        $dataStatement->bind_param('ssssssii', $periodStart, $periodEnd, $search, $search, $barangay, $barangay, $day, $day);
        $dataStatement->execute();
        $dataResult = $dataStatement->get_result();
        while ($row = $dataResult->fetch_assoc()) {
            $reportRows[] = $row;
        }
        $dataStatement->close();
    }
} catch (Throwable $exception) {
    error_log('Unable to load staff report: ' . $exception->getMessage());
    $pageError = 'The report could not be generated. Please try again later.';
}
$totalPages = max(1, (int) ceil($reportTotal / $pageSize));
$pageNumber = min($pageNumber, $totalPages);
$offset = ($pageNumber - 1) * $pageSize;
$monthNames = [0 => 'All Months', 1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'];
$queryParameters = ['type' => $reportType, 'month' => $month, 'year' => $year, 'day' => $day];
if ($barangay !== '') $queryParameters['barangay'] = $barangay;
if ($search !== '') $queryParameters['search'] = $search;

if ($csvExport && $pageError === '') {
    try {
        writeActivityLog($databaseConnection, (int) ($_SESSION['user_id'] ?? 0), 'export', 'Reports', $reportTypes[$reportType]['name'] . ' CSV export for ' . $periodLabel . '.');
    } catch (Throwable $exception) {
        error_log('Unable to log staff report export: ' . $exception->getMessage());
    }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $reportType . '_report_' . $year . '_' . ($month === 0 ? 'all_months' : sprintf('%02d', $month)) . '.csv"');
    $output = fopen('php://output', 'wb');
    fwrite($output, "\xEF\xBB\xBF");
    fputcsv($output, $reportHeaders);
    foreach ($reportRows as $index => $row) {
        $values = array_values($row);
        if ($reportType === 'senior') array_unshift($values, (string) ($index + 1));
        fputcsv($output, array_map(static function ($value): string {
            $value = (string) ($value ?? '');
            return preg_match('/^[=+\-@\t\r]/', $value) ? "'" . $value : $value;
        }, $values));
    }
    fclose($output);
    exit;
}
$paginationPages = array_values(array_unique(array_filter(
    [1, $pageNumber - 2, $pageNumber - 1, $pageNumber, $pageNumber + 1, $pageNumber + 2, $totalPages],
    static fn ($number): bool => $number >= 1 && $number <= $totalPages
)));
sort($paginationPages);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo staffReportsEscape($page_title); ?></title>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="assets/reports.css?v=11">
    <link rel="stylesheet" href="/BMirk/staff/assets/table.css?v=18">
</head>
<body>
    <div class="staff-layout">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <main class="staff-main">
            <?php include __DIR__ . '/../includes/header.php'; ?>
            <section class="staff-content reports-page">
                <header class="reports-heading"><h1>Reports</h1><p>Generate monthly reports for records and system activity.</p></header>
                <?php if ($pageError !== ''): ?><div class="reports-error" role="alert"><?php echo staffReportsEscape($pageError); ?></div><?php endif; ?>
                <nav class="report-tabs" aria-label="Report types">
                    <?php foreach ($reportTypes as $key => $type): ?>
                        <?php $tabParameters = $queryParameters; $tabParameters['type'] = $key; unset($tabParameters['search']); ?>
                        <a class="report-tab <?php echo $reportType === $key ? 'active' : ''; ?>" href="?<?php echo staffReportsEscape(http_build_query($tabParameters)); ?>" <?php echo $reportType === $key ? 'aria-current="page"' : ''; ?>><?php echo staffReportsEscape($type['name']); ?></a>
                    <?php endforeach; ?>
                </nav>
                <form class="report-period-card" method="get" action="">
                    <div class="report-period-heading"><strong>Report Period</strong></div>
                    <div class="report-period-controls">
                        <label for="reportMonth"><span>Month</span><select id="reportMonth" name="month"><?php foreach ($monthNames as $monthNumber => $monthName): ?><option value="<?php echo $monthNumber; ?>" <?php echo $month === $monthNumber ? 'selected' : ''; ?>><?php echo staffReportsEscape($monthName); ?></option><?php endforeach; ?></select></label>
                        <label for="reportYear"><span>Year</span><select id="reportYear" name="year"><?php for ($availableYear = $currentYear; $availableYear >= 2000; $availableYear--): ?><option value="<?php echo $availableYear; ?>" <?php echo $year === $availableYear ? 'selected' : ''; ?>><?php echo $availableYear; ?></option><?php endfor; ?></select></label>
                        <label for="reportDay"><span>Day</span><select id="reportDay" name="day" aria-label="Filter by day"><option value="0">All Days</option><?php for ($dayNumber = 1; $dayNumber <= 31; $dayNumber++): ?><option value="<?php echo $dayNumber; ?>" <?php echo $day === $dayNumber ? 'selected' : ''; ?>><?php echo $dayNumber; ?></option><?php endfor; ?></select></label>
                        <?php if ($reportType === 'senior'): ?><label for="reportBarangay"><span>Barangay</span><select id="reportBarangay" name="barangay" aria-label="Filter by barangay"><option value="">All Barangays</option><?php foreach ($barangayOptions as $barangayOption): ?><option value="<?php echo staffReportsEscape($barangayOption); ?>" <?php echo $barangay === $barangayOption ? 'selected' : ''; ?>><?php echo staffReportsEscape($barangayOption); ?></option><?php endforeach; ?></select></label><?php endif; ?>
                        <input type="hidden" name="type" value="<?php echo staffReportsEscape($reportType); ?>">
                        <button class="report-primary-button" type="submit">Generate Report</button>
                    </div>
                    <div class="report-export-controls"><div class="report-export-dropdown"><button class="report-primary-button report-export-toggle" type="button" id="reportExportToggle" aria-expanded="false" aria-controls="reportExportMenu">Export</button><div class="report-export-menu" id="reportExportMenu" hidden><button type="button" data-report-print>Print</button><button type="button" data-report-pdf>Export PDF</button><a href="?<?php $csvParameters = $queryParameters; $csvParameters['export'] = 'csv'; echo staffReportsEscape(http_build_query($csvParameters)); ?>">Export CSV</a></div></div></div>
                </form>
                <section class="report-output" aria-labelledby="reportOutputHeading">
                    <header class="report-output-heading"><h2 id="reportOutputHeading"><?php echo staffReportsEscape($reportTypes[$reportType]['summary']); ?></h2><p>Summary for <?php echo staffReportsEscape($periodLabel); ?></p></header>
                    <?php if ($reportType === 'senior'): ?>
                        <div class="senior-report-metrics" aria-label="Senior record totals for <?php echo staffReportsEscape($periodLabel); ?>">
                            <article class="metric-total"><span>Total Seniors</span><strong><?php echo number_format($seniorMetrics['total']); ?></strong><small><?php echo staffReportsEscape($periodLabel); ?></small></article>
                            <article class="metric-male"><span>Male</span><strong><?php echo number_format($seniorMetrics['male']); ?></strong><small><?php echo staffReportsEscape($periodLabel); ?></small></article>
                            <article class="metric-female"><span>Female</span><strong><?php echo number_format($seniorMetrics['female']); ?></strong><small><?php echo staffReportsEscape($periodLabel); ?></small></article>
                            <article class="metric-active"><span>Active</span><strong><?php echo number_format($seniorMetrics['active']); ?></strong><small><?php echo staffReportsEscape($periodLabel); ?></small></article>
                            <article class="metric-pending"><span>Pending</span><strong><?php echo number_format($seniorMetrics['pending']); ?></strong><small><?php echo staffReportsEscape($periodLabel); ?></small></article>
                            <article class="metric-deceased"><span>Deceased</span><strong><?php echo number_format($seniorMetrics['deceased']); ?></strong><small><?php echo staffReportsEscape($periodLabel); ?></small></article>
                        </div>
                    <?php else: ?>
                        <div class="generic-report-summary"><article><span>Total Records</span><strong><?php echo number_format($reportTotal); ?></strong><small><?php echo staffReportsEscape($periodLabel); ?></small></article></div>
                    <?php endif; ?>
                    <section class="report-breakdown-card generic-records-card">
                        <div class="generic-records-heading">
                            <h3><?php echo staffReportsEscape($reportTypes[$reportType]['name']); ?> Records</h3>
                            <?php if ($reportType !== 'senior'): ?><form class="report-search-form" method="get" action="">
                                <input type="hidden" name="type" value="<?php echo staffReportsEscape($reportType); ?>"><input type="hidden" name="month" value="<?php echo $month; ?>"><input type="hidden" name="year" value="<?php echo $year; ?>"><input type="hidden" name="day" value="<?php echo $day; ?>"><?php if ($barangay !== ''): ?><input type="hidden" name="barangay" value="<?php echo staffReportsEscape($barangay); ?>"><?php endif; ?>
                                <input type="search" name="search" value="<?php echo staffReportsEscape($search); ?>" placeholder="Search..." aria-label="Search report records"><button type="submit">Search</button>
                            </form><?php endif; ?>
                        </div>
                        <div class="report-table-scroll staff-consistent-table-wrap"><table class="data-table staff-consistent-table report-detail-table generic-report-table">
                            <thead><tr><?php foreach ($reportHeaders as $header): ?><th scope="col"><?php echo staffReportsEscape($header); ?></th><?php endforeach; ?></tr></thead>
                            <tbody>
                                <?php if ($pageError !== ''): ?><tr><td colspan="<?php echo count($reportHeaders); ?>" class="report-empty">Report records are unavailable.</td></tr>
                                <?php elseif (!$reportRows): ?><tr><td colspan="<?php echo count($reportHeaders); ?>" class="report-empty"><?php echo $search !== '' ? 'No records match your search.' : 'No records found for this month.'; ?></td></tr>
                                <?php else: foreach ($reportRows as $rowIndex => $row): ?><tr><?php if ($reportType === 'senior'): ?><td><?php echo $offset + $rowIndex + 1; ?></td><?php endif; ?><?php foreach ($row as $column => $value): ?><td><?php echo staffReportsEscape($column === 'date_added' ? date('M j, Y', strtotime((string) $value)) : (in_array($column, ['sex', 'status'], true) ? ucfirst((string) $value) : $value)); ?></td><?php endforeach; ?></tr><?php endforeach; endif; ?>
                            </tbody>
                        </table></div>
                        <footer class="report-results-footer staff-consistent-table-footer">
                            <p class="staff-consistent-result-count"><?php if ($reportTotal > 0 && $pageError === ''): ?>Showing <?php echo $offset + 1; ?> to <?php echo min($offset + count($reportRows), $reportTotal); ?> of <?php echo number_format($reportTotal); ?> entries<?php else: ?>Showing 0 entries<?php endif; ?></p>
                            <?php if ($totalPages > 1 && $pageError === ''): ?><nav class="report-pagination" aria-label="Report pages"><a class="<?php echo $pageNumber <= 1 ? 'disabled' : ''; ?>" href="?<?php echo staffReportsEscape(http_build_query($queryParameters + ['search' => $search, 'page' => max(1, $pageNumber - 1)])); ?>">Previous</a><?php foreach ($paginationPages as $visiblePage): ?><a class="<?php echo $visiblePage === $pageNumber ? 'active' : ''; ?>" href="?<?php echo staffReportsEscape(http_build_query($queryParameters + ['search' => $search, 'page' => $visiblePage])); ?>" <?php echo $visiblePage === $pageNumber ? 'aria-current="page"' : ''; ?>><?php echo $visiblePage; ?></a><?php endforeach; ?><a class="<?php echo $pageNumber >= $totalPages ? 'disabled' : ''; ?>" href="?<?php echo staffReportsEscape(http_build_query($queryParameters + ['search' => $search, 'page' => min($totalPages, $pageNumber + 1)])); ?>">Next</a></nav><?php endif; ?>
                        </footer>
                    </section>
                </section>
            </section>
        </main>
    </div>
    <script>
        (function () {
            var toggle = document.getElementById('reportExportToggle');
            var menu = document.getElementById('reportExportMenu');
            if (!toggle || !menu) return;
            toggle.addEventListener('click', function () {
                var open = this.getAttribute('aria-expanded') !== 'true';
                this.setAttribute('aria-expanded', String(open));
                menu.hidden = !open;
            });
            menu.querySelectorAll('[data-report-print], [data-report-pdf]').forEach(function (action) {
                action.addEventListener('click', function () {
                    menu.hidden = true;
                    toggle.setAttribute('aria-expanded', 'false');
                    window.print();
                });
            });
            document.addEventListener('click', function (event) {
                if (!event.target.closest('.report-export-dropdown')) {
                    menu.hidden = true;
                    toggle.setAttribute('aria-expanded', 'false');
                }
            });
            document.addEventListener('keydown', function (event) {
                if (event.key === 'Escape') {
                    menu.hidden = true;
                    toggle.setAttribute('aria-expanded', 'false');
                }
            });
        }());
        document.querySelectorAll('.report-search-form input[type="search"]').forEach(function (searchInput) {
            let searchTimeout;
            searchInput.addEventListener('input', function () {
                window.clearTimeout(searchTimeout);
                searchTimeout = window.setTimeout(function () { searchInput.form.requestSubmit(); }, 300);
            });
        });
    </script>
</body>
</html>
