<?php $currentSeniorPage = basename($_SERVER['PHP_SELF'] ?? ''); ?>
<link rel="stylesheet" href="/BMirk/admin/includes/assets/sidebar.css?v=10">

<aside class="admin-sidebar" id="shared-admin-sidebar">
	<div class="sidebar-brand">InfoConnect</div>
	<nav class="sidebar-nav" aria-label="Senior navigation">
		<a href="/BMirk/senior/home.php" class="sidebar-link <?php echo $currentSeniorPage === 'home.php' ? 'active' : ''; ?>"<?php echo $currentSeniorPage === 'home.php' ? ' aria-current="page"' : ''; ?>><svg class="sidebar-icon" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="m2.5 10.8 9.5-8 9.5 8"/><path d="M4.5 9.7V21h15V9.7M9 21v-6.5h6V21"/><path d="M7.5 11.5h1m7 0h1"/></svg><span>Home</span></a>
		<a href="/BMirk/senior/events.php" class="sidebar-link <?php echo $currentSeniorPage === 'events.php' ? 'active' : ''; ?>"<?php echo $currentSeniorPage === 'events.php' ? ' aria-current="page"' : ''; ?>><svg class="sidebar-icon" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/><path d="m8 15 2.5 2.5L16 12"/></svg><span>Events</span></a>
		<a href="/BMirk/senior/history.php" class="sidebar-link <?php echo $currentSeniorPage === 'history.php' ? 'active' : ''; ?>"<?php echo $currentSeniorPage === 'history.php' ? ' aria-current="page"' : ''; ?>><svg class="sidebar-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12a9 9 0 1 0 2.6-6.4L3 8"/><path d="M3 3v5h5m4-1v5l3.5 2"/></svg><span>History</span></a>
		<div class="nav-group<?php echo $currentSeniorPage === 'settings.php' ? ' open' : ''; ?>">
			<button class="nav-button" type="button" aria-expanded="<?php echo $currentSeniorPage === 'settings.php' ? 'true' : 'false'; ?>"><svg class="sidebar-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m9.8 2.8.5-1h3.4l.5 1 1.1 1.5 1.8.2 1.2-.3 2.4 2.4-.3 1.2.2 1.8 1.5 1.1 1 .5v3.4l-1 .5-1.5 1.1-.2 1.8.3 1.2-2.4 2.4-1.2-.3-1.8.2-1.1 1.5-.5 1h-3.4l-.5-1-1.1-1.5-1.8-.2-1.2.3-2.4-2.4.3-1.2-.2-1.8-1.5-1.1-1-.5v-3.4l1-.5 1.5-1.1.2-1.8-.3-1.2 2.4-2.4 1.2.3 1.8-.2z"/><circle cx="12" cy="12" r="4"/></svg><span>Settings</span></button>
			<div class="submenu"><div class="submenu-inner">
				<a href="/BMirk/senior/settings.php#my-profile" class="<?php echo $currentSeniorPage === 'settings.php' ? 'active' : ''; ?>"<?php echo $currentSeniorPage === 'settings.php' ? ' aria-current="page"' : ''; ?>>My Profile</a>
				<a href="/BMirk/senior/settings.php#change-password">Change Password</a>
			</div></div>
		</div>
		<a href="/BMirk/auth/logout.php?portal=senior" class="sidebar-link logout-link"><svg class="sidebar-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M13 3.5h6.5v17H13"/><path d="M14 12H3.5m0 0 4-4m-4 4 4 4"/></svg><span>Logout</span></a>
	</nav>
</aside>

<script>
	document.querySelectorAll('.nav-button').forEach(function (button) {
		button.addEventListener('click', function () {
			const group = this.closest('.nav-group');
			const willOpen = !group.classList.contains('open');
			document.querySelectorAll('.nav-group').forEach(function (item) {
				item.classList.remove('open');
				const itemButton = item.querySelector(':scope > .nav-button');
				if (itemButton) itemButton.setAttribute('aria-expanded', 'false');
			});
			if (willOpen) {
				group.classList.add('open');
				this.setAttribute('aria-expanded', 'true');
			}
		});
	});
</script>
