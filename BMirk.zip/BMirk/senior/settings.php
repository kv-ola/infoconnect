<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/activity_log.php';
require_once __DIR__ . '/../config/system_settings.php';
requireLogin();
require_once __DIR__ . '/includes/portal_helpers.php';
$senior = requireSeniorPortalUser();
$userId = $senior['user_id'];
$errors = [];
$success = '';
if (empty($_SESSION['senior_settings_csrf'])) {
	$_SESSION['senior_settings_csrf'] = bin2hex(random_bytes(32));
}
$passwordSettings = loadSystemSettings($databaseConnection);
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
	$currentPassword = is_string($_POST['current_password'] ?? null) ? $_POST['current_password'] : '';
	$newPassword = is_string($_POST['new_password'] ?? null) ? $_POST['new_password'] : '';
	$confirmPassword = is_string($_POST['confirm_password'] ?? null) ? $_POST['confirm_password'] : '';
	$token = is_string($_POST['csrf_token'] ?? null) ? $_POST['csrf_token'] : '';
	if (!hash_equals($_SESSION['senior_settings_csrf'], $token)) { $errors[] = 'Your session expired. Refresh the page and try again.'; }
	if ($currentPassword === '' || $newPassword === '' || $confirmPassword === '') { $errors[] = 'Complete all password fields.'; }
	$errors = array_merge($errors, systemPasswordPolicyErrors($newPassword, $passwordSettings));
	if ($newPassword !== '' && $confirmPassword !== '' && $newPassword !== $confirmPassword) { $errors[] = 'The new password and confirmation do not match.'; }
	$user = null;
	if (!$errors) {
		$check = $databaseConnection->prepare("SELECT password FROM users WHERE id = ? AND role = 'senior' AND status = 'active' LIMIT 1");
		$check->bind_param('i', $userId);
		$check->execute();
		$user = $check->get_result()->fetch_assoc() ?: null;
		$check->close();
		if (!$user || !password_verify($currentPassword, $user['password'])) { $errors[] = 'The current password is incorrect.'; }
		elseif (password_verify($newPassword, $user['password'])) { $errors[] = 'Choose a password that is different from your current password.'; }
	}
	if (!$errors && $user) {
		$historyQuery = $databaseConnection->prepare('SELECT password_hash FROM password_history WHERE user_id = ?');
		$historyQuery->bind_param('i', $userId);
		$historyQuery->execute();
		$historyResult = $historyQuery->get_result();
		while ($oldPassword = $historyResult->fetch_assoc()) {
			if (password_verify($newPassword, $oldPassword['password_hash'])) { $errors[] = 'This password has been used before. Choose a different one.'; break; }
		}
		$historyQuery->close();
	}
	if (!$errors && $user) {
		$newHash = password_hash($newPassword, PASSWORD_DEFAULT);
		try {
			$databaseConnection->begin_transaction();
			$historyInsert = $databaseConnection->prepare('INSERT INTO password_history (user_id, password_hash) VALUES (?, ?)');
			$historyInsert->bind_param('is', $userId, $user['password']);
			$historyInsert->execute();
			$historyInsert->close();
			$update = $databaseConnection->prepare("UPDATE users SET password = ?, must_change_password = 0 WHERE id = ? AND role = 'senior' AND status = 'active'");
			$update->bind_param('si', $newHash, $userId);
			$update->execute();
			if ($update->affected_rows !== 1) { throw new RuntimeException('Password update affected no account.'); }
			$update->close();
			writeActivityLog($databaseConnection, $userId, 'update', 'Authentication', 'Changed account password.');
			$databaseConnection->commit();
			$success = 'Your password was updated.';
			$_SESSION['senior_settings_csrf'] = bin2hex(random_bytes(32));
		} catch (Throwable $exception) {
			$databaseConnection->rollback();
			error_log('Senior password update failed: ' . $exception->getMessage());
			$errors[] = 'Unable to update your password. Please try again.';
		}
	}
}
$profileQuery = $databaseConnection->prepare('SELECT sp.senior_citizen_id, sp.first_name, sp.middle_name, sp.last_name, sp.suffix, sp.sex, sp.birth_date, sp.place_of_birth, sp.address, sp.barangay, sp.contact_number, sp.residence_since, sp.company_name, sp.position, sp.is_pwd, sp.is_bedridden, sp.status AS profile_status, sp.approval_status, cs.name AS civil_status, ea.name AS education, o.name AS occupation, pt.name AS pension_type, u.account_id, u.status AS account_status, u.created_at, u.last_login
	FROM senior_profiles sp JOIN users u ON u.id = sp.user_id
	LEFT JOIN civil_statuses cs ON cs.id = sp.civil_status_id
	LEFT JOIN educational_attainments ea ON ea.id = sp.educational_attainment_id
	LEFT JOIN occupations o ON o.id = sp.former_occupation_id
	LEFT JOIN pension_types pt ON pt.id = sp.pension_type_id
	WHERE sp.user_id = ? LIMIT 1');
$profileQuery->bind_param('i', $userId);
$profileQuery->execute();
$profile = $profileQuery->get_result()->fetch_assoc() ?: [];
$profileQuery->close();
$fullName = implode(' ', array_filter([$profile['first_name'] ?? '', $profile['middle_name'] ?? '', $profile['last_name'] ?? '', $profile['suffix'] ?? '']));
$age = !empty($profile['birth_date']) ? (new DateTimeImmutable($profile['birth_date']))->diff(new DateTimeImmutable('today'))->y : null;
$details = [
	'Senior ID' => $profile['senior_citizen_id'] ?? '', 'Full name' => $fullName,
	'Sex' => ucfirst($profile['sex'] ?? ''), 'Date of birth' => !empty($profile['birth_date']) ? date('F j, Y', strtotime($profile['birth_date'])) : '',
	'Age' => $age === null ? '' : $age . ' years', 'Place of birth' => $profile['place_of_birth'] ?? '',
	'Civil status' => $profile['civil_status'] ?? '', 'Address' => $profile['address'] ?? '',
	'Barangay' => $profile['barangay'] ?? '', 'Contact number' => $profile['contact_number'] ?? '',
	'Resident since' => $profile['residence_since'] ?? '', 'Education' => $profile['education'] ?? '',
	'Former occupation' => $profile['occupation'] ?? '', 'Company' => $profile['company_name'] ?? '',
	'Position' => $profile['position'] ?? '', 'Pension type' => $profile['pension_type'] ?? '',
	'PWD' => !empty($profile['is_pwd']) ? 'Yes' : 'No', 'Bedridden' => !empty($profile['is_bedridden']) ? 'Yes' : 'No',
	'Profile status' => ucfirst($profile['profile_status'] ?? ''), 'Approval status' => ucfirst($profile['approval_status'] ?? ''),
	'Account ID' => $profile['account_id'] ?? '', 'Account status' => ucfirst($profile['account_status'] ?? ''),
	'Last login' => !empty($profile['last_login']) ? date('M j, Y g:i A', strtotime($profile['last_login'])) : 'Not available',
];
seniorPortalPageStart('Settings', $senior['name'], 'View your profile and manage your password.');
?>
<?php if ($success !== ''): ?><div class="portal-success" role="status"><?php echo seniorEscape($success); ?></div><?php endif; ?>
<?php if ($errors): ?><ul class="portal-errors" role="alert"><?php foreach (array_unique($errors) as $error): ?><li><?php echo seniorEscape($error); ?></li><?php endforeach; ?></ul><?php endif; ?>
<section class="portal-card portal-section-anchor" id="my-profile" aria-labelledby="profile-heading">
	<h3 id="profile-heading">My Profile</h3>
	<div class="portal-table-wrap"><table class="portal-table"><tbody><?php foreach ($details as $label => $value): ?><tr><th scope="row"><?php echo seniorEscape($label); ?></th><td><?php echo seniorEscape($value !== '' ? $value : '—'); ?></td></tr><?php endforeach; ?></tbody></table></div>
</section>
<section class="portal-card portal-section-anchor" id="change-password" aria-labelledby="password-heading">
	<h3 id="password-heading">Change Password</h3>
	<form class="portal-form" method="post" action="/BMirk/senior/settings.php#change-password">
		<input type="hidden" name="csrf_token" value="<?php echo seniorEscape($_SESSION['senior_settings_csrf']); ?>">
		<div class="portal-form-grid">
			<div class="portal-field"><label for="current_password">Current password</label><input class="portal-input" id="current_password" name="current_password" type="password" autocomplete="current-password" required></div>
			<div class="portal-field"><label for="new_password">New password</label><input class="portal-input" id="new_password" name="new_password" type="password" minlength="<?php echo max(8, (int) $passwordSettings['password_minimum_length']); ?>" maxlength="72" autocomplete="new-password" required></div>
			<div class="portal-field"><label for="confirm_password">Confirm new password</label><input class="portal-input" id="confirm_password" name="confirm_password" type="password" minlength="<?php echo max(8, (int) $passwordSettings['password_minimum_length']); ?>" maxlength="72" autocomplete="new-password" required></div>
		</div>
		<p class="portal-help">Use at least <?php echo max(8, (int) $passwordSettings['password_minimum_length']); ?> characters<?php echo $passwordSettings['password_require_special_characters'] === '1' ? ' and include a special character' : ''; ?>.</p>
		<div><button class="portal-button" type="submit">Update Password</button></div>
	</form>
</section>
<?php seniorPortalPageEnd(); ?>
