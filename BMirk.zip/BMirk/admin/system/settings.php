<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/activity_log.php';
require_once __DIR__ . '/../../config/system_settings.php';
require_once __DIR__ . '/../../config/system_backup.php';
requireLogin();

if (($_SESSION['role'] ?? '') !== 'admin') {
	header('Location: /BMirk/auth/login.php');
	exit;
}

$page_title = 'Settings';
$headerSubtitle = 'Manage your system settings and configurations.';
$adminId = (int) ($_SESSION['user_id'] ?? 0);
$settingsTabs = [
	'personal' => ['label' => 'Personal', 'file' => 'personal.php', 'css' => 'personal.css'],
	'account' => ['label' => 'Account', 'file' => 'account.php', 'css' => 'account.css'],
	'security' => ['label' => 'Security', 'file' => 'security.php', 'css' => 'security.css'],
	'backup' => ['label' => 'Backup & Recovery', 'file' => 'backup&recovery.php', 'css' => 'backup&recovery.css'],
	'about' => ['label' => 'About System', 'file' => 'about.php', 'css' => 'about.css'],
];
$settingsTab = is_string($_GET['tab'] ?? null) && isset($settingsTabs[$_GET['tab']]) ? $_GET['tab'] : 'personal';
$errors = [];
$successMessage = $_SESSION['settings_flash'] ?? ($_SESSION['password_flash'] ?? '');
unset($_SESSION['settings_flash']);
unset($_SESSION['password_flash']);
$profileError = '';
$adminProfile = [];

if (empty($_SESSION['password_csrf_token'])) {
	$_SESSION['password_csrf_token'] = bin2hex(random_bytes(32));
}
if (empty($_SESSION['system_settings_csrf_token'])) {
	$_SESSION['system_settings_csrf_token'] = bin2hex(random_bytes(32));
}

try {
	$settingsValues = loadSystemSettings($databaseConnection);
} catch (Throwable $exception) {
	error_log('Unable to load system settings: ' . $exception->getMessage());
	$settingsValues = getSystemSettingDefaults();
	$errors[] = 'System settings could not be loaded. Apply the system settings database migration and try again.';
}

if (isset($_GET['download']) && is_string($_GET['download'])) {
	$downloadName = $_GET['download'];
	if (!preg_match('/^infoconnect_(?:scheduled_)?\d{4}-\d{2}-\d{2}_\d{6}\.sql$/', $downloadName)) {
		http_response_code(400);
		exit('Invalid backup file.');
	}
	$downloadPath = systemBackupDirectory() . DIRECTORY_SEPARATOR . $downloadName;
	if (!is_file($downloadPath)) {
		http_response_code(404);
		exit('Backup file not found.');
	}
	header('Content-Type: application/sql');
	header('Content-Disposition: attachment; filename="' . $downloadName . '"');
	header('Content-Length: ' . filesize($downloadPath));
	readfile($downloadPath);
	exit;
}

try {
	$profileStatement = $databaseConnection->prepare(
		"SELECT u.account_id, u.role, u.status AS account_status, u.created_at AS account_created_at,
		        ap.employee_id, ap.first_name, ap.middle_name, ap.last_name, ap.email, ap.contact_number
		 FROM users u
		 LEFT JOIN admin_profiles ap ON ap.user_id = u.id
		 WHERE u.id = ? AND u.role = 'admin'
		 LIMIT 1"
	);
	if (!$profileStatement) {
		throw new RuntimeException('Unable to prepare administrator profile query.');
	}
	$profileStatement->bind_param('i', $adminId);
	if (!$profileStatement->execute()) {
		throw new RuntimeException('Unable to load administrator profile.');
	}
	$adminProfile = $profileStatement->get_result()->fetch_assoc() ?: [];
	$profileStatement->close();
} catch (Throwable $exception) {
	error_log('Unable to load system settings profile: ' . $exception->getMessage());
	$profileError = 'Your personal information could not be loaded.';
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['settings_action'])) {
	$settingsAction = is_string($_POST['settings_action']) ? $_POST['settings_action'] : '';
	$settingsToken = is_string($_POST['settings_csrf_token'] ?? null) ? $_POST['settings_csrf_token'] : '';
	if (!hash_equals($_SESSION['system_settings_csrf_token'], $settingsToken)) {
		$errors[] = 'Your session token expired. Refresh the page and try again.';
	} else {
		try {
			if ($settingsAction === 'save_account') {
				$autoDeactivateDays = filter_var($_POST['auto_deactivate_days'] ?? null, FILTER_VALIDATE_INT);
				$requireChange = $_POST['require_password_change_first_login'] ?? '';
				if ($autoDeactivateDays === false || $autoDeactivateDays < 1 || $autoDeactivateDays > 3650) {
					$errors[] = 'Inactive account days must be between 1 and 3650.';
				}
				if (!in_array($requireChange, ['0', '1'], true)) {
					$errors[] = 'Choose whether new accounts must change their password on first login.';
				}
				if (!$errors) {
					$settingsValues['auto_deactivate_days'] = (string) $autoDeactivateDays;
					$settingsValues['require_password_change_first_login'] = $requireChange;
					saveSystemSettings($databaseConnection, $settingsValues);
					writeActivityLog($databaseConnection, $adminId, 'update', 'Settings', 'Updated account settings.');
					$_SESSION['settings_flash'] = 'Account settings were saved.';
					header('Location: /BMirk/admin/system/settings.php?tab=account', true, 303);
					exit;
				}
			} elseif ($settingsAction === 'save_security') {
				$minimumLength = filter_var($_POST['password_minimum_length'] ?? null, FILTER_VALIDATE_INT);
				$requireSpecialCharacters = $_POST['password_require_special_characters'] ?? '';
				$loginAttemptLimit = filter_var($_POST['login_attempt_limit'] ?? null, FILTER_VALIDATE_INT);
				$passwordExpirationDays = filter_var($_POST['password_expiration_days'] ?? null, FILTER_VALIDATE_INT);
				if ($minimumLength === false || $minimumLength < 8 || $minimumLength > 72) {
					$errors[] = 'Minimum password length must be between 8 and 72 characters.';
				}
				if (!in_array($requireSpecialCharacters, ['0', '1'], true)) {
					$errors[] = 'Choose whether passwords require special characters.';
				}
				if ($loginAttemptLimit === false || $loginAttemptLimit < 1 || $loginAttemptLimit > 20) {
					$errors[] = 'Login attempt limit must be between 1 and 20.';
				}
				if ($passwordExpirationDays === false || $passwordExpirationDays < 0 || $passwordExpirationDays > 3650) {
					$errors[] = 'Password expiration must be between 0 and 3650 days.';
				}
				if (!$errors) {
					$settingsValues['password_minimum_length'] = (string) $minimumLength;
					$settingsValues['password_require_special_characters'] = $requireSpecialCharacters;
					$settingsValues['login_attempt_limit'] = (string) $loginAttemptLimit;
					$settingsValues['password_expiration_days'] = (string) $passwordExpirationDays;
					saveSystemSettings($databaseConnection, $settingsValues);
					writeActivityLog($databaseConnection, $adminId, 'update', 'Settings', 'Updated security settings.');
					$_SESSION['settings_flash'] = 'Security settings were saved.';
					header('Location: /BMirk/admin/system/settings.php?tab=security', true, 303);
					exit;
				}
			} elseif ($settingsAction === 'save_backup') {
				$backupEnabled = $_POST['automatic_backup_enabled'] ?? '';
				$backupFrequency = $_POST['automatic_backup_frequency'] ?? '';
				if (!in_array($backupEnabled, ['0', '1'], true)) {
					$errors[] = 'Choose whether automatic backups are enabled.';
				}
				if (!in_array($backupFrequency, ['daily', 'weekly', 'monthly'], true)) {
					$errors[] = 'Choose a valid automatic backup frequency.';
				}
				if (!$errors) {
					$settingsValues['automatic_backup_enabled'] = $backupEnabled;
					$settingsValues['automatic_backup_frequency'] = $backupFrequency;
					saveSystemSettings($databaseConnection, $settingsValues);
					writeActivityLog($databaseConnection, $adminId, 'update', 'Settings', 'Updated automatic backup settings.');
					$_SESSION['settings_flash'] = 'Backup settings were saved.';
					header('Location: /BMirk/admin/system/settings.php?tab=backup', true, 303);
					exit;
				}
			} elseif ($settingsAction === 'create_backup') {
				$filename = runSystemDatabaseBackup(
					['host' => $dbHost, 'user' => $dbUser, 'password' => $dbPass, 'name' => $dbName],
					'manual'
				);
				writeActivityLog($databaseConnection, $adminId, 'create', 'Settings', 'Created database backup ' . $filename . '.');
				$_SESSION['settings_flash'] = 'Database backup created: ' . $filename;
				header('Location: /BMirk/admin/system/settings.php?tab=backup', true, 303);
				exit;
			} elseif ($settingsAction === 'restore_backup') {
				$confirmation = is_string($_POST['restore_confirmation'] ?? null) ? $_POST['restore_confirmation'] : '';
				$upload = $_FILES['backup_file'] ?? null;
				if ($confirmation !== 'RESTORE') {
					$errors[] = 'Type RESTORE exactly to confirm database replacement.';
				} elseif (!is_array($upload) || ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($upload['tmp_name'] ?? '')) {
					$errors[] = 'Choose a valid SQL backup file to restore.';
				} elseif (($upload['size'] ?? 0) < 1 || $upload['size'] > 200 * 1024 * 1024 || strtolower(pathinfo($upload['name'], PATHINFO_EXTENSION)) !== 'sql') {
					$errors[] = 'Choose an SQL file no larger than 200 MB.';
				} else {
					runSystemDatabaseBackup(
						['host' => $dbHost, 'user' => $dbUser, 'password' => $dbPass, 'name' => $dbName],
						'manual'
					);
					restoreSystemDatabaseBackup(
						['host' => $dbHost, 'user' => $dbUser, 'password' => $dbPass, 'name' => $dbName],
						$upload['tmp_name']
					);
					writeActivityLog($databaseConnection, $adminId, 'restore', 'Settings', 'Restored the system database from an uploaded SQL backup.');
					$_SESSION['settings_flash'] = 'Database restore completed.';
					header('Location: /BMirk/admin/system/settings.php?tab=backup', true, 303);
					exit;
				}
			} else {
				$errors[] = 'Choose a valid settings action.';
			}
		} catch (Throwable $exception) {
			error_log('Unable to process system settings action: ' . $exception->getMessage());
			$errors[] = $exception->getMessage();
		}
	}
} elseif (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
	$currentPassword = is_string($_POST['current_password'] ?? null) ? $_POST['current_password'] : '';
	$newPassword = is_string($_POST['new_password'] ?? null) ? $_POST['new_password'] : '';
	$confirmPassword = is_string($_POST['confirm_password'] ?? null) ? $_POST['confirm_password'] : '';
	$submittedToken = is_string($_POST['csrf_token'] ?? null) ? $_POST['csrf_token'] : '';

	if (!hash_equals($_SESSION['password_csrf_token'], $submittedToken)) {
		$errors[] = 'Your session token expired. Refresh the page and try again.';
	}
	if ($currentPassword === '' || $newPassword === '' || $confirmPassword === '') {
		$errors[] = 'Complete all password fields.';
	}
	$errors = array_merge($errors, systemPasswordPolicyErrors($newPassword, $settingsValues));
	if ($newPassword !== '' && $confirmPassword !== '' && $newPassword !== $confirmPassword) {
		$errors[] = 'The new password and confirmation do not match.';
	}

	$currentPasswordHash = '';
	if (!$errors) {
		$passwordStatement = $databaseConnection->prepare("SELECT password FROM users WHERE id = ? AND role = 'admin' LIMIT 1");
		if (!$passwordStatement) {
			$errors[] = 'Unable to verify your account. Please try again.';
		} else {
			$passwordStatement->bind_param('i', $adminId);
			if (!$passwordStatement->execute()) {
				$errors[] = 'Unable to verify your account. Please try again.';
			} else {
				$admin = $passwordStatement->get_result()->fetch_assoc();
				if (!$admin || !password_verify($currentPassword, $admin['password'])) {
					$errors[] = 'The current password is incorrect.';
				} elseif (password_verify($newPassword, $admin['password'])) {
					$errors[] = 'Choose a new password that is different from your current password.';
				} else {
					$currentPasswordHash = $admin['password'];
				}
			}
			$passwordStatement->close();
		}
	}

	if (!$errors) {
		$historyStatement = $databaseConnection->prepare('SELECT password_hash FROM password_history WHERE user_id = ?');
		if (!$historyStatement) {
			$errors[] = 'Unable to check password history. Please try again.';
		} else {
			$historyStatement->bind_param('i', $adminId);
			if (!$historyStatement->execute()) {
				$errors[] = 'Unable to check password history. Please try again.';
			} else {
				$historyResult = $historyStatement->get_result();
				while ($historyRow = $historyResult->fetch_assoc()) {
					if (password_verify($newPassword, $historyRow['password_hash'])) {
						$errors[] = 'This password has been used before. Choose a different password.';
						break;
					}
				}
			}
			$historyStatement->close();
		}
	}

	if (!$errors) {
		$newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
		if ($newPasswordHash === false) {
			$errors[] = 'Unable to secure the new password. Please try again.';
		} else {
			try {
				$databaseConnection->begin_transaction();
				$historyInsert = $databaseConnection->prepare('INSERT INTO password_history (user_id, password_hash) VALUES (?, ?)');
				$updateStatement = $databaseConnection->prepare("UPDATE users SET password = ?, must_change_password = 0 WHERE id = ? AND role = 'admin'");
				if (!$historyInsert || !$updateStatement) {
					throw new RuntimeException('Unable to prepare password update.');
				}
				$historyInsert->bind_param('is', $adminId, $currentPasswordHash);
				if (!$historyInsert->execute()) {
					throw new RuntimeException('Unable to save password history.');
				}
				$updateStatement->bind_param('si', $newPasswordHash, $adminId);
				if (!$updateStatement->execute() || $updateStatement->affected_rows !== 1) {
					throw new RuntimeException('Unable to update password.');
				}
				writeActivityLog($databaseConnection, $adminId, 'update', 'Settings', 'Changed administrator password.');
				$databaseConnection->commit();
				$_SESSION['password_flash'] = 'Your password was changed successfully.';
				$_SESSION['password_csrf_token'] = bin2hex(random_bytes(32));
				header('Location: /BMirk/admin/system/settings.php?tab=personal', true, 303);
				exit;
			} catch (Throwable $exception) {
				$databaseConnection->rollback();
				error_log('Unable to change administrator password: ' . $exception->getMessage());
				$errors[] = 'Unable to update your password. Please try again.';
			}
		}
	}
}

function escapeSettingsValue($value): string
{
	return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$activeSettings = $settingsTabs[$settingsTab];
$backupFiles = [];
if ($settingsTab === 'backup') {
	try {
		$backupFiles = systemBackupFiles();
	} catch (Throwable $exception) {
		error_log('Unable to read database backup history: ' . $exception->getMessage());
		$errors[] = 'Backup history could not be loaded.';
	}
}
$databaseVersion = '';
if ($settingsTab === 'about') {
	$versionResult = $databaseConnection->query('SELECT VERSION() AS version');
	$databaseVersion = (string) ($versionResult->fetch_assoc()['version'] ?? '');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo escapeSettingsValue($page_title); ?></title>
	<link rel="stylesheet" href="../home.css">
	<link rel="stylesheet" href="settings/assets/<?php echo escapeSettingsValue($activeSettings['css']); ?>?v=2">
	<link rel="stylesheet" href="settings.css?v=3">
</head>
<body>
	<div class="admin-layout">
		<?php include __DIR__ . '/../includes/sidebar.php'; ?>
		<main class="admin-main">
			<?php include __DIR__ . '/../includes/header.php'; ?>
			<section class="admin-content settings-content">
				<header class="settings-page-heading">
					<h2>Settings</h2>
					<p>Manage your system settings and configurations.</p>
				</header>
				<div class="settings-layout">
					<aside class="settings-navigation">
						<h3>Settings</h3>
						<p>Manage your system settings.</p>
						<nav aria-label="Settings sections">
							<?php foreach ($settingsTabs as $tabKey => $tab): ?>
								<a href="?tab=<?php echo escapeSettingsValue($tabKey); ?>" class="<?php echo $settingsTab === $tabKey ? 'active' : ''; ?>"<?php echo $settingsTab === $tabKey ? ' aria-current="page"' : ''; ?>><?php echo escapeSettingsValue($tab['label']); ?></a>
							<?php endforeach; ?>
						</nav>
					</aside>
					<section class="settings-panel">
						<?php if ($successMessage !== ''): ?>
							<div class="settings-message success" role="status"><?php echo escapeSettingsValue($successMessage); ?></div>
						<?php endif; ?>
						<?php if ($errors): ?>
							<div class="settings-message error" role="alert"><ul><?php foreach ($errors as $error): ?><li><?php echo escapeSettingsValue($error); ?></li><?php endforeach; ?></ul></div>
						<?php endif; ?>
						<?php if ($profileError !== ''): ?>
							<div class="settings-message error" role="alert"><?php echo escapeSettingsValue($profileError); ?></div>
						<?php endif; ?>
						<?php include __DIR__ . '/settings/' . $activeSettings['file']; ?>
					</section>
				</div>
			</section>
		</main>
	</div>
	<script src="../assets/password-strength.js" defer></script>
</body>
</html>
